from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from config.settings import get_settings
from core.liquidity.institutional_zones import detect_institutional_zones
from core.liquidity.whale_tracker import track_whales
from core.market_halt import check_market_halt
from core.sentiment.anomaly_detector import detect_sentiment_anomaly
from core.sentiment.sentiment_analyzer import SentimentBias, analyze_sentiment
from core.sentiment.social_sentiment import SocialBias, analyze_social_sentiment
from data.models.candle import Candle

if TYPE_CHECKING:
    from core.analyzer import AnalysisResult


@dataclass(frozen=True)
class HybridDecision:
    allowed: bool
    halted: bool
    final_signal: str
    technical_passed: bool
    sentiment_ok: bool
    macro_ok: bool
    liquidity_ok: bool
    reasons: tuple[str, ...]


def evaluate_hybrid(
    symbol: str,
    technical: "AnalysisResult",
    *,
    m15_candles: list[Candle] | None = None,
) -> HybridDecision:
    reasons: list[str] = []
    trial_mode = bool(get_settings().trial_mode)

    halt = check_market_halt()
    if halt.halted:
        return HybridDecision(
            allowed=False,
            halted=True,
            final_signal="HALTED",
            technical_passed=technical.passed,
            sentiment_ok=False,
            macro_ok=False,
            liquidity_ok=False,
            reasons=(halt.reason,),
        )

    reasons.append(halt.reason)

    sentiment = analyze_sentiment()
    reasons.append(sentiment.reason)

    social = analyze_social_sentiment(symbol)
    reasons.append(social.reason)

    if m15_candles and not trial_mode:
        anomaly = detect_sentiment_anomaly(m15_candles)
        reasons.append(anomaly.reason)
        if anomaly.detected:
            return HybridDecision(
                allowed=False,
                halted=False,
                final_signal="REJECTED",
                technical_passed=technical.passed,
                sentiment_ok=False,
                macro_ok=True,
                liquidity_ok=False,
                reasons=tuple(reasons),
            )

    whales = track_whales(symbol)
    institutional = detect_institutional_zones(symbol, whale_result=whales)
    reasons.append(whales.reason)
    reasons.append(institutional.reason)

    is_buy = technical.passed and technical.signal == "BUY SIGNAL"
    is_sell = technical.passed and technical.signal == "SELL SIGNAL"

    # مرحلة التجربة: لا تحوّل BUY/SELL التقني إلى WAIT بسبب Fear&Greed / Social
    if trial_mode and (is_buy or is_sell):
        if is_buy and sentiment.is_extreme and sentiment.bias == SentimentBias.BEARISH:
            return HybridDecision(
                allowed=False,
                halted=False,
                final_signal="REJECTED",
                technical_passed=True,
                sentiment_ok=False,
                macro_ok=True,
                liquidity_ok=True,
                reasons=(*reasons, "تجربة: رفض لأن المشاعر هابطة جداً"),
            )
        if is_sell and sentiment.is_extreme and sentiment.bias == SentimentBias.BULLISH:
            return HybridDecision(
                allowed=False,
                halted=False,
                final_signal="REJECTED",
                technical_passed=True,
                sentiment_ok=False,
                macro_ok=True,
                liquidity_ok=True,
                reasons=(*reasons, "تجربة: رفض لأن المشاعر صاعدة جداً"),
            )
        signal = "BUY SIGNAL" if is_buy else "SELL SIGNAL"
        return HybridDecision(
            allowed=True,
            halted=False,
            final_signal=signal,
            technical_passed=True,
            sentiment_ok=True,
            macro_ok=True,
            liquidity_ok=True,
            reasons=(*reasons, "تجربة: مرور هجين — فتح فني مؤهل"),
        )

    if is_buy:
        if sentiment.is_extreme and sentiment.bias == SentimentBias.BEARISH:
            return HybridDecision(
                allowed=False,
                halted=False,
                final_signal="REJECTED",
                technical_passed=True,
                sentiment_ok=False,
                macro_ok=True,
                liquidity_ok=False,
                reasons=tuple(reasons),
            )
        sentiment_ok = sentiment.bias != SentimentBias.BEARISH
        if social.bias == SocialBias.BEARISH:
            sentiment_ok = False
        liquidity_ok = whales.has_whale_support or institutional.has_bid_cluster
        if liquidity_ok and sentiment_ok:
            return HybridDecision(
                allowed=True,
                halted=False,
                final_signal="BUY SIGNAL",
                technical_passed=True,
                sentiment_ok=True,
                macro_ok=True,
                liquidity_ok=True,
                reasons=tuple(reasons),
            )
        return HybridDecision(
            allowed=False,
            halted=False,
            final_signal="WAIT",
            technical_passed=True,
            sentiment_ok=sentiment_ok,
            macro_ok=True,
            liquidity_ok=liquidity_ok,
            reasons=tuple(reasons),
        )

    if is_sell:
        if sentiment.is_extreme and sentiment.bias == SentimentBias.BULLISH:
            return HybridDecision(
                allowed=False,
                halted=False,
                final_signal="REJECTED",
                technical_passed=True,
                sentiment_ok=False,
                macro_ok=True,
                liquidity_ok=False,
                reasons=tuple(reasons),
            )
        sentiment_ok = sentiment.bias != SentimentBias.BULLISH
        if social.bias == SocialBias.BULLISH:
            sentiment_ok = False
        liquidity_ok = whales.has_whale_resistance or institutional.has_ask_cluster
        if liquidity_ok and sentiment_ok:
            return HybridDecision(
                allowed=True,
                halted=False,
                final_signal="SELL SIGNAL",
                technical_passed=True,
                sentiment_ok=True,
                macro_ok=True,
                liquidity_ok=True,
                reasons=tuple(reasons),
            )
        return HybridDecision(
            allowed=False,
            halted=False,
            final_signal="WAIT",
            technical_passed=True,
            sentiment_ok=sentiment_ok,
            macro_ok=True,
            liquidity_ok=liquidity_ok,
            reasons=tuple(reasons),
        )

    liquidity_ok = whales.has_whale_support or institutional.has_bid_cluster
    sentiment_ok = sentiment.bias != SentimentBias.BEARISH
    return HybridDecision(
        allowed=False,
        halted=False,
        final_signal=technical.signal,
        technical_passed=technical.passed,
        sentiment_ok=sentiment_ok,
        macro_ok=True,
        liquidity_ok=liquidity_ok,
        reasons=tuple(reasons),
    )
