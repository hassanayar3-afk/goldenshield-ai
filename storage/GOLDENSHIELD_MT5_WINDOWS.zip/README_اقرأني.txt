GOLDENSHIELD — Windows MT5 (حزمة تثبيت كاملة)
========================================
1) Extract All الى C:\GoldenShield
2) شغّل فحص_المجلد_CHECK.bat
3) افتح XM MT5 وسجّل دخول يدوياً
4) شغّل 00_فحص_MT5.bat واتبع التعليمات
5) شغّل 00_START.bat
6) Disconnect RDP — لا تعمل Log off أو Shutdown

القانون الحديدي الكامل داخل:
docs\GOLDENSHIELD_IRON_LAW_COMPLETE_AR.md
