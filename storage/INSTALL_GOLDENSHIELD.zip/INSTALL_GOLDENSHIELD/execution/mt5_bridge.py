"""جسر MetaTrader 5 (XM) — يعمل فقط على Windows مع طرفية MT5 مفتوحة."""

from __future__ import annotations

import logging
import sys
from dataclasses import dataclass
from typing import Any

from config.settings import get_settings
from core.exceptions import ExecutionError

logger = logging.getLogger(__name__)

# رموز المشروع (Binance) → رموز شائعة على XM MT5
DEFAULT_SYMBOL_MAP: dict[str, str] = {
    "BTC/USDT": "BTCUSD",
    "ETH/USDT": "ETHUSD",
    "BNB/USDT": "BNBUSD",
    "SOL/USDT": "SOLUSD",
    "XRP/USDT": "XRPUSD",
    "ADA/USDT": "ADAUSD",
    "LINK/USDT": "LINKUSD",
    "AVAX/USDT": "AVAXUSD",
}


@dataclass(frozen=True)
class MT5OrderResult:
    ticket: int
    symbol: str
    volume: float
    price: float
    retcode: int


def is_windows() -> bool:
    return sys.platform.startswith("win")


def map_symbol(binance_symbol: str) -> str:
    try:
        from operations.symbol_registry import get_symbol_registry

        return get_symbol_registry().mt5_symbol_for(binance_symbol)
    except Exception:
        return DEFAULT_SYMBOL_MAP.get(binance_symbol, binance_symbol.replace("/", ""))


class MT5Bridge:
    """واجهة رفيعة حول حزمة MetaTrader5."""

    def __init__(self) -> None:
        self._mt5: Any | None = None
        self._connected = False

    @property
    def connected(self) -> bool:
        return self._connected

    def _import_mt5(self) -> Any:
        if not is_windows():
            raise ExecutionError(
                "MetaTrader5 يتطلب Windows + طرفية MT5. Contabo الحالي Linux — اشترِ Windows VPS."
            )
        try:
            import MetaTrader5 as mt5  # type: ignore
        except ImportError as exc:
            raise ExecutionError(
                "حزمة MetaTrader5 غير مثبتة. على Windows: pip install MetaTrader5"
            ) from exc
        return mt5

    def connect(self) -> None:
        settings = get_settings()
        if not settings.mt5_enabled:
            raise ExecutionError("MT5_ENABLED=false — لم يُفعَّل الربط بعد")
        if not settings.mt5_login or not settings.mt5_password or not settings.mt5_server:
            raise ExecutionError("أكمل MT5_LOGIN و MT5_PASSWORD و MT5_SERVER في .env")

        mt5 = self._import_mt5()
        if not mt5.initialize():
            raise ExecutionError(f"فشل تشغيل طرفية MT5: {mt5.last_error()}")

        authorized = mt5.login(
            int(settings.mt5_login),
            password=settings.mt5_password,
            server=settings.mt5_server,
        )
        if not authorized:
            err = mt5.last_error()
            mt5.shutdown()
            raise ExecutionError(f"فشل تسجيل دخول XM/MT5: {err}")

        self._mt5 = mt5
        self._connected = True
        info = mt5.account_info()
        logger.info(
            "MT5 connected | login=%s server=%s balance=%s",
            settings.mt5_login,
            settings.mt5_server,
            getattr(info, "balance", "?"),
        )

    def ensure_connected(self) -> Any:
        if not self._connected or self._mt5 is None:
            self.connect()
        assert self._mt5 is not None
        return self._mt5

    def shutdown(self) -> None:
        if self._mt5 is not None:
            try:
                self._mt5.shutdown()
            except Exception:
                logger.exception("MT5 shutdown error")
        self._mt5 = None
        self._connected = False

    def account_balance(self) -> float:
        mt5 = self.ensure_connected()
        info = mt5.account_info()
        if info is None:
            raise ExecutionError(f"تعذر قراءة رصيد MT5: {mt5.last_error()}")
        return float(info.balance)

    def resolve_symbol(self, binance_symbol: str) -> str:
        mt5 = self.ensure_connected()
        candidates: list[str] = []
        primary = map_symbol(binance_symbol)
        candidates.append(primary)
        if primary.startswith("#"):
            candidates.append(primary.lstrip("#"))
        if binance_symbol.startswith("STOCK/"):
            ticker = binance_symbol.split("/", 1)[1]
            candidates.extend([f"#{ticker}", ticker, f"{ticker}.US", f"{ticker}m"])
        if binance_symbol.startswith("FOREX/"):
            candidates.append(binance_symbol.split("/", 1)[1])

        seen: set[str] = set()
        for candidate in candidates:
            if not candidate or candidate in seen:
                continue
            seen.add(candidate)
            info = mt5.symbol_info(candidate)
            if info is None:
                if mt5.symbol_select(candidate, True):
                    info = mt5.symbol_info(candidate)
            if info is None:
                continue
            if not info.visible:
                mt5.symbol_select(candidate, True)
            return candidate
        raise ExecutionError(f"رمز MT5 غير موجود لـ {binance_symbol} — جرّب /add أو /sync_mt5")

    def volume_from_amount(self, mt5_symbol: str, amount: float) -> float:
        """يحول كمية العملة تقريباً إلى لوت حسب volume_step."""
        mt5 = self.ensure_connected()
        info = mt5.symbol_info(mt5_symbol)
        if info is None:
            raise ExecutionError(f"لا معلومات حجم لـ {mt5_symbol}")
        step = float(info.volume_step or 0.01)
        vmin = float(info.volume_min or step)
        vmax = float(info.volume_max or 100.0)
        # amount عندنا بوحدات الأصل؛ على CFD غالباً 1 lot ≈ عقد محدد — نقرّب بلطف
        volume = max(vmin, round(amount / max(step, 1e-8)) * step)
        # إن كانت الكمية صغيرة جداً استخدم الحد الأدنى
        if amount > 0 and volume < vmin:
            volume = vmin
        volume = min(max(volume, vmin), vmax)
        # تقريب لعدد منازل الخطوة
        decimals = max(0, str(step)[::-1].find("."))
        return round(volume, decimals if decimals > 0 else 2)

    def place_market(
        self,
        binance_symbol: str,
        *,
        side: str,
        amount: float,
        stop_loss: float | None = None,
        take_profit: float | None = None,
    ) -> MT5OrderResult:
        mt5 = self.ensure_connected()
        symbol = self.resolve_symbol(binance_symbol)
        volume = self.volume_from_amount(symbol, amount)
        tick = mt5.symbol_info_tick(symbol)
        if tick is None:
            raise ExecutionError(f"لا سعر حي لـ {symbol}")

        is_buy = side.lower() in {"buy", "long"}
        order_type = mt5.ORDER_TYPE_BUY if is_buy else mt5.ORDER_TYPE_SELL
        price = float(tick.ask if is_buy else tick.bid)

        request: dict[str, Any] = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": volume,
            "type": order_type,
            "price": price,
            "deviation": 30,
            "magic": 20260714,
            "comment": "GoldenShield",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        if stop_loss is not None and stop_loss > 0:
            request["sl"] = float(stop_loss)
        if take_profit is not None and take_profit > 0:
            request["tp"] = float(take_profit)

        result = mt5.order_send(request)
        if result is None:
            raise ExecutionError(f"order_send فشل: {mt5.last_error()}")
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            raise ExecutionError(
                f"رفض MT5 الأمر retcode={result.retcode} comment={getattr(result, 'comment', '')}"
            )
        fill = float(result.price or price)
        return MT5OrderResult(
            ticket=int(result.order or result.deal or 0),
            symbol=symbol,
            volume=volume,
            price=fill,
            retcode=int(result.retcode),
        )

    def modify_position_sl_tp(
        self,
        binance_symbol: str,
        *,
        stop_loss: float | None = None,
        take_profit: float | None = None,
    ) -> bool:
        """تعديل SL/TP على مركز MT5 المفتوح (يظهر في تطبيق الهاتف)."""
        if stop_loss is None and take_profit is None:
            return False

        mt5 = self.ensure_connected()
        symbol = self.resolve_symbol(binance_symbol)
        positions = mt5.positions_get(symbol=symbol)
        if not positions:
            raise ExecutionError(f"لا مركز مفتوح على MT5 لـ {symbol}")

        position = None
        for item in positions:
            if int(getattr(item, "magic", 0)) == 20260714:
                position = item
                break
        if position is None:
            position = positions[-1]

        request: dict[str, Any] = {
            "action": mt5.TRADE_ACTION_SLTP,
            "position": int(position.ticket),
            "symbol": symbol,
            "sl": float(stop_loss) if stop_loss is not None and stop_loss > 0 else float(position.sl),
            "tp": float(take_profit) if take_profit is not None and take_profit > 0 else float(position.tp),
        }
        result = mt5.order_send(request)
        if result is None:
            raise ExecutionError(f"تعديل SL/TP فشل: {mt5.last_error()}")
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            raise ExecutionError(
                f"رفض MT5 تعديل SL/TP retcode={result.retcode} "
                f"comment={getattr(result, 'comment', '')}"
            )
        logger.info(
            "MT5 SL/TP updated %s ticket=%s sl=%s tp=%s",
            symbol,
            position.ticket,
            request["sl"],
            request["tp"],
        )
        return True

    def discover_tradeable_symbols(self) -> list[dict[str, str]]:
        """يكتشف عملات وفوركس متاحة على MT5 — للمزامنة التلقائية."""
        mt5 = self.ensure_connected()
        crypto_bases = {
            "BTC", "ETH", "BNB", "SOL", "XRP", "ADA", "LINK", "AVAX",
            "DOGE", "DOT", "MATIC", "LTC", "TRX", "ATOM", "BCH", "ETC",
        }
        forex_pairs = {
            "EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "USDCHF", "NZDUSD",
        }
        found: list[dict[str, str]] = []
        symbols = mt5.symbols_get() or []
        for item in symbols:
            name = str(item.name)
            if name in forex_pairs:
                found.append({"kind": "forex", "id": f"FOREX/{name}", "mt5": name})
                continue
            if name.endswith("USD") and len(name) > 3:
                base = name[:-3]
                if base in crypto_bases:
                    found.append({"kind": "crypto", "id": f"{base}/USDT", "mt5": name})
        return found


_bridge: MT5Bridge | None = None


def get_mt5_bridge() -> MT5Bridge:
    global _bridge
    if _bridge is None:
        _bridge = MT5Bridge()
    return _bridge
