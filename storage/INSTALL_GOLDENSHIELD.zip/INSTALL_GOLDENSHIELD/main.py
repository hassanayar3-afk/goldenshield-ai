import asyncio
import logging
import sys

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from audit.audit_trail import AuditTrail
from audit.decision_logger import DecisionLogger
from audit.snapshot_recorder import SnapshotRecorder
from core.constants import meets_auto_entry_minimum, score_to_percent
from config.settings import get_settings
from core.market_halt import check_market_halt
from data.connection_monitor import ConnectionMonitor
from data.ticker_fetcher import TickerFetcher
from database.backup_manager import BackupManager, BackupScheduler
from database.connection import init_database
from database.gdrive_uploader import upload_backup
from database.telegram_backup import upload_backup_to_telegram
from database.repositories.config_repo import ConfigRepository
from database.repositories.operations_repo import OperationsRepository
from database.repositories.snapshot_repo import SnapshotRepository
from database.repositories.trade_repo import TradeRepository
from execution.trade_executor import TradeExecutor
from operations.alert_dispatcher import AlertDispatcher
from operations.api_watchdog import ApiWatchdog
from operations.daily_report import format_daily_report, format_daily_report_telegram
from operations.message_templates import format_cycle_signals_message, format_signal_message, format_startup_message
from operations.error_logger import set_db_log_sink, setup_operations_logging
from operations.signal_filter import is_premium_trade_signal
from operations.panic_button import PanicButton
from operations.pre_flight_checklist import run_pre_flight
from operations.runtime_state import OperationsRuntime
from operations.bot_admin import bot_may_auto_expand
from operations.symbol_registry import get_symbol_registry
from operations.shutdown_guard import is_user_stopped, should_block_signals
from operations.scheduler import DailyReportScheduler
from operations.telegram_commands import TelegramCommandHandler
from risk.heartbeat_guard import check_heartbeat_guard
from risk.risk_orchestrator import RiskOrchestrator

logger = logging.getLogger(__name__)

_connection_monitor = ConnectionMonitor()
_audit = AuditTrail()
_risk = RiskOrchestrator(connection_monitor=_connection_monitor)
_executor = TradeExecutor(risk_orchestrator=_risk, audit_trail=_audit)
_ticker_fetcher = TickerFetcher()
_runtime = OperationsRuntime(
    manual_entry_required=get_settings().manual_entry_required,
)
_alerts = AlertDispatcher()
_panic = PanicButton(_executor, _alerts)
_report_scheduler = DailyReportScheduler()
_backup_scheduler = BackupScheduler()
_backup_manager: BackupManager | None = None
_operations_repo: OperationsRepository | None = None
_kill_switch_notified = False
_watchdog_cycle = 0
_watchlist_sent = False
_telegram_handler: TelegramCommandHandler | None = None


def _init_persistence(settings) -> None:
    global _audit, _backup_manager, _operations_repo

    db = init_database(settings.db_path)
    snapshot_repo = SnapshotRepository(db)
    trade_repo = TradeRepository(db)
    config_repo = ConfigRepository(db)
    _operations_repo = OperationsRepository(db)

    from database.repositories.risk_state_repo import load_risk_state, save_risk_state

    def _persist_risk(state, session_day) -> None:
        save_risk_state(config_repo, state, session_day)

    _risk.set_persist_callback(_persist_risk)
    saved_state, saved_day = load_risk_state(config_repo)
    if saved_state is not None:
        _risk.restore_state(saved_state, saved_day)
        logger.info(
            "Restored risk state (balance=%.2f, kill=%s, losses=%s)",
            saved_state.current_balance,
            saved_state.kill_switch_active,
            saved_state.consecutive_losses,
        )

    _audit = AuditTrail(
        snapshot_recorder=SnapshotRecorder(repository=snapshot_repo),
        decision_logger=DecisionLogger(repository=trade_repo),
    )
    _executor.audit = _audit
    _executor.trade_repo = trade_repo
    _executor.alerts = _alerts
    restored = _executor.restore_open_positions()
    if restored:
        logger.info("Open positions restored: %s", restored)

    _backup_manager = BackupManager(settings.db_path)

    set_db_log_sink(_operations_repo.save_operation_log)
    config_repo.set("last_startup_env", settings.env)
    config_repo.set("telegram_chat_id", settings.telegram_chat_id or "")
    logger.info("Database ready: %s", settings.db_path)


def _fetch_prices(symbols: list[str]) -> dict[str, float]:
    prices: dict[str, float] = {}
    for symbol in symbols:
        try:
            prices[symbol] = _ticker_fetcher.fetch(symbol).last
        except Exception as exc:
            logger.warning("فشل جلب سعر %s: %s", symbol, exc)
    return prices


def _sync_risk_session() -> None:
    balance = _executor.get_account_balance()
    _risk.ensure_state(balance)


def _emergency_flat_if_needed(reason: str, symbols: list[str]) -> None:
    if not _executor.position_manager.count():
        return
    prices = _fetch_prices(symbols)
    closed = _executor.emergency_close_all(prices)
    if closed:
        msg = f"Emergency Flat ({reason}): {', '.join(closed)}"
        print(f"🚨 {msg}")
        _alerts.emergency("Emergency Flat", msg)


def _notify_kill_switch_if_needed() -> None:
    global _kill_switch_notified
    state = _risk.state
    if state and state.kill_switch_active and not _kill_switch_notified:
        _alerts.kill_switch_activated(
            f"PnL اليومي {state.daily_pnl_pct:+.2f}% — تداول موقوف"
        )
        _kill_switch_notified = True


def _maybe_send_daily_report() -> None:
    if not _report_scheduler.should_run_daily_report():
        return
    from datetime import date

    report = format_daily_report(risk=_risk, executor=_executor, audit=_audit)
    report_html = format_daily_report_telegram(risk=_risk, executor=_executor, audit=_audit)
    print(report)
    # في وضع الإشارات فقط: يبقى التقرير في السجل/قاعدة البيانات دون إزعاج تيليجرام
    if not get_settings().telegram_signals_only:
        _alerts.send_formatted(report_html, plain_log=f"[INFO] تقرير يومي\n{report}")
    else:
        from operations.error_logger import log_operation

        log_operation(f"[INFO] تقرير يومي (صامت على تيليجرام)\n{report}")
    if _operations_repo is not None:
        _operations_repo.save_daily_report(date.today().isoformat(), report)
    _report_scheduler.mark_daily_report_sent()


def _maybe_run_daily_backup() -> None:
    if _backup_manager is None or not _backup_scheduler.should_run_backup():
        return
    result = _backup_manager.create_backup()
    if result.success:
        logger.info(result.message)
        vault = upload_backup_to_telegram(result.path or "")
        if vault.uploaded:
            logger.info(vault.message)
        else:
            logger.info("Telegram Vault: %s", vault.message)
        gdrive = upload_backup(result.path or "")
        if not gdrive.uploaded:
            logger.info("GDrive: %s", gdrive.message)
    _backup_scheduler.mark_backup_done()


def _send_cycle_signals(entries: list[dict]) -> None:
    if not entries:
        return
    msg = format_cycle_signals_message(entries)
    plain_lines = [
        f"{entry['symbol']}: {entry['signal']} ({entry['score']}/10 @ {entry['price']:.2f})"
        for entry in entries
    ]
    _alerts.send_formatted(msg, plain_log="[INFO] تحديث الإشارات\n" + "\n".join(plain_lines))


def _notify_signal(symbol: str, result, *, extra: str = "") -> None:
    """إرسال إشارة مؤهلة فقط — BUY بدرجة ≥75% وموافقات النظام."""
    if should_block_signals() or _runtime.user_stopped:
        return
    if result.signal != "BUY SIGNAL":
        return

    entry = {
        "symbol": symbol,
        "price": result.price,
        "score": result.score,
        "signal": result.signal,
        "premium": True,
    }
    if _telegram_handler is not None:
        _telegram_handler.send_trade_opportunity(
            symbol,
            entry,
            reasons=result.reasons,
        )
        return

    msg = format_signal_message(
        symbol=symbol,
        price=result.price,
        score=result.score,
        signal=result.signal,
        extra=extra,
        kind="buy",
    )
    plain = f"[INFO] إشارة مؤهلة {symbol}\nالسعر: {result.price:.2f}\nالدرجة: {result.score}/10"
    _alerts.send_formatted(msg, plain_log=plain)


def _maybe_send_watchlist_digest(telegram_handler: TelegramCommandHandler, entries: list[dict]) -> None:
    global _watchlist_sent
    if get_settings().telegram_signals_only:
        return
    if _watchlist_sent or not entries or not telegram_handler.enabled:
        return
    telegram_handler.send_watchlist_digest()
    _watchlist_sent = True


async def check_symbol(symbol: str) -> dict | None:
    """فحص الرمز ثم محاولة التنفيذ عند تأهل الإشارة."""
    if _runtime.user_stopped or should_block_signals():
        return None
    try:
        analyzer = MarketAnalyzer(symbol=symbol)
        result = analyzer.analyze()

        if result.price <= 0:
            print(f"❌ {symbol} | فشل جلب البيانات (تأكد من اتصالك أو اسم الزوج)")
            return None

        snapshot, consensus = _audit.record_market_check(result)
        signal_label = "HALTED" if result.halted else result.signal
        balance = _executor.get_account_balance()
        risk_approval = _risk.evaluate_entry(
            symbol, result.price, balance, signal_score=result.score
        )
        premium = is_premium_trade_signal(
            result, consensus=consensus, risk_approval=risk_approval
        )
        entry = {
            "symbol": symbol,
            "price": result.price,
            "score": result.score,
            "signal": signal_label,
            "reasons": result.reasons,
            "premium": premium,
        }

        print(
            f"✅ {symbol} | السعر: {result.price:.2f} | "
            f"الدرجة: {result.score}/10 | الحالة: {result.signal}"
            + (" | ⭐ مؤهلة" if premium else "")
        )

        if result.halted:
            print(f"⏸️ {symbol} متوقف — {result.reasons[-1]}")
            _audit.log_analysis_outcome(snapshot, result)
            return entry

        if result.signal == "REJECTED":
            print(f"⛔ {symbol} مرفوض — {result.reasons[0]}")
            _audit.log_analysis_outcome(snapshot, result)
            return entry

        if result.signal != "BUY SIGNAL" or not result.passed:
            _audit.log_analysis_outcome(snapshot, result, consensus=consensus)
            return entry

        if not consensus.approved:
            _audit.log_analysis_outcome(snapshot, result, consensus=consensus)
            print(f"🚫 رفض Shadow {symbol}: {consensus.reason}")
            return entry

        if not premium:
            _audit.log_analysis_outcome(snapshot, result, consensus=consensus)
            print(f"⏳ {symbol}: BUY لكن المخاطر لم توافق — لا إشعار Telegram")
            return entry

        settings = get_settings()
        auto_ok = meets_auto_entry_minimum(
            result.score, auto_percent=settings.auto_entry_min_percent
        )
        pct = score_to_percent(result.score)

        # مختلط: ≥ عتبة التلقائي → فتح بدون زر؛ وإلا (أو MANUAL=true) إشعار + انتظار
        if _runtime.manual_entry_required or not auto_ok:
            reason = (
                "يدوي مفروض (MANUAL_ENTRY_REQUIRED)"
                if _runtime.manual_entry_required
                else f"يدوي — التلقائي من {settings.auto_entry_min_percent}/100"
            )
            _notify_signal(symbol, result, extra=reason)
            _audit.log_analysis_outcome(snapshot, result, consensus=consensus)
            print(
                f"📲 {symbol}: {pct}/100 — بانتظار موافقتك "
                f"(تلقائي ≥{settings.auto_entry_min_percent}/100)"
            )
            return entry

        exec_result = _executor.try_open(result, snapshot=snapshot, consensus=consensus)
        if exec_result.executed:
            print(f"📈 تنفيذ تلقائي ({pct}/100): {exec_result.message}")
            _alerts.trade_opened(symbol, exec_result.message)
        elif exec_result.rejected:
            print(f"🚫 رفض تنفيذ {symbol}: {exec_result.reason}")
            _notify_signal(symbol, result, extra="فشل التلقائي — يمكنك الدخول يدوياً")
        else:
            _notify_signal(
                symbol,
                result,
                extra=f"تلقائي ≥{settings.auto_entry_min_percent}/100 — جاري المتابعة",
            )

        return entry

    except Exception as exc:
        logger.exception("خطأ أثناء معالجة %s", symbol)
        print(f"⚠️ خطأ أثناء معالجة {symbol}: {exc}")
        return None


async def run_bot() -> None:
    global _telegram_handler
    settings = get_settings()
    setup_operations_logging(settings.log_level)

    if is_user_stopped():
        print("🛑 البوت متوقف بقرارك — شغّل 00_START.bat لإعادة التشغيل.")
        sys.exit(0)

    preflight = run_pre_flight(connection_monitor=_connection_monitor)
    for check in preflight.checks:
        icon = "✅" if check.passed else "❌"
        print(f"{icon} Pre-Flight | {check.name}: {check.detail}")

    if not preflight.ok:
        print("🛑 فشل Pre-Flight — إيقاف التشغيل")
        sys.exit(1)

    _init_persistence(settings)

    registry = get_symbol_registry()
    active_symbols = registry.load(settings.trading_pairs)
    if bot_may_auto_expand() and (settings.mt5_enabled or settings.execution_backend == "mt5"):
        try:
            added = registry.sync_from_mt5()
            if added:
                active_symbols = registry.active_pairs()
                print(f"🔄 MT5 sync: أُضيف {len(added)} رمز — {', '.join(added)}")
        except Exception as exc:
            logger.warning("MT5 auto-sync skipped: %s", exc)
    if settings.bot_admin_full_access:
        for pair in ("EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "USDCHF", "NZDUSD"):
            registry.add_forex(pair, enabled=True)
        for ticker in ("AAPL", "TSLA", "NVDA", "MSFT", "GOOGL", "AMZN", "META"):
            registry.add_stock(ticker, enabled=True)
        active_symbols = registry.active_pairs()
        print(f"📋 صلاحيات كاملة: {len(active_symbols)} رمز نشط")

    telegram_handler = TelegramCommandHandler(
        runtime=_runtime,
        executor=_executor,
        risk=_risk,
        panic=_panic,
        audit=_audit,
        price_fetcher=_fetch_prices,
    )
    _telegram_handler = telegram_handler
    if telegram_handler.enabled:
        asyncio.create_task(telegram_handler.poll_loop())

    mode = settings.execution_mode.upper()
    startup_plain = (
        f"GoldenShield AI [{settings.env}/{mode}] — "
        f"أزواج: {', '.join(active_symbols)} | DB: {settings.db_path}"
    )
    print(f"--- 🛡️ {startup_plain} ---")
    if telegram_handler.enabled and not settings.telegram_signals_only:
        telegram_handler.dashboard.send_main_menu()
    elif telegram_handler.enabled and settings.telegram_signals_only:
        print("📲 تيليجرام: وضع إشارات/صفقات فقط (بدون قائمة وتشغيل)")
    else:
        startup_html = format_startup_message(
            env=settings.env,
            mode=mode,
            pairs=active_symbols,
            db_path=settings.db_path,
        )
        _alerts.send_formatted(startup_html, plain_log=f"[INFO] بدء التشغيل\n{startup_plain}")
    _maybe_send_daily_report()
    _maybe_run_daily_backup()

    while True:
        if _runtime.user_stopped or is_user_stopped():
            print("🛑 إيقاف دائم — لا إشارات ولا إعادة تشغيل حتى 00_START.bat")
            break

        telegram_handler.poll_once()
        _maybe_send_daily_report()
        _maybe_run_daily_backup()

        global _watchdog_cycle
        _watchdog_cycle += 1
        if _watchdog_cycle % 10 == 0:
            watchdog = ApiWatchdog().run(_connection_monitor)
            if not watchdog.ok:
                logger.warning("ApiWatchdog: %s", ", ".join(watchdog.failures))

        if _runtime.paused:
            print("⏸️ التداول موقوف (أمر Telegram أو Panic)")
            await asyncio.sleep(settings.loop_interval_seconds)
            continue

        symbols = get_symbol_registry().active_pairs()
        _sync_risk_session()
        _notify_kill_switch_if_needed()

        if not _connection_monitor.heartbeat():
            print("⚠️ انقطاع الاتصال بـ Binance — تخطي هذه الدورة")
            heartbeat = check_heartbeat_guard(_connection_monitor)
            if heartbeat.should_emergency_flat:
                _emergency_flat_if_needed(heartbeat.reason, symbols)
            await asyncio.sleep(settings.loop_interval_seconds)
            continue

        if _connection_monitor.is_disconnected():
            print(
                f"⚠️ لا اتصال منذ أكثر من {_connection_monitor.timeout_seconds} ثانية — تخطي التداول"
            )
            _emergency_flat_if_needed("انقطاع Heartbeat", symbols)
            await asyncio.sleep(settings.loop_interval_seconds)
            continue

        market_halt = check_market_halt()
        if market_halt.halted:
            print(f"⏸️ توقف السوق: {market_halt.reason}")
            _emergency_flat_if_needed(f"توقف السوق: {market_halt.reason}", symbols)
            await asyncio.sleep(settings.loop_interval_seconds)
            continue

        if _risk.state and _risk.state.kill_switch_active:
            print("🛑 Kill Switch مفعّل — تداول موقوف لهذا اليوم")
            await asyncio.sleep(settings.loop_interval_seconds)
            continue

        cycle_results = await asyncio.gather(*[check_symbol(s) for s in symbols])
        cycle_entries = [entry for entry in cycle_results if entry]
        prices = _fetch_prices(symbols)
        if cycle_entries:
            reasons_map = {
                entry["symbol"]: entry.get("reasons", ())
                for entry in cycle_entries
            }
            telegram_handler.update_market_snapshot(
                cycle_entries,
                prices,
                reasons=reasons_map,
            )
            _maybe_send_watchlist_digest(telegram_handler, cycle_entries)
        if settings.telegram_send_cycle_signals:
            _send_cycle_signals(cycle_entries)

        breakeven_actions = _executor.manage_positions(prices)
        for action in breakeven_actions:
            if action.reason:
                print(f"⚖️ Breakeven: {action.reason}")

        open_count = _executor.position_manager.count()
        audit_count = len(_audit.decisions.records)
        if open_count:
            print(f"📊 مراكز مفتوحة: {open_count} | سجلات تدقيق: {audit_count}")

        print(f"--- 🔄 تحديث الدورة اكتمل. انتظار {settings.loop_interval_seconds} ثانية... ---")
        await asyncio.sleep(settings.loop_interval_seconds)


if __name__ == "__main__":
    try:
        asyncio.run(run_bot())
    except KeyboardInterrupt:
        _runtime.stop_permanently(reason="keyboard_interrupt")
        print("\n--- 🛑 تم إيقاف البوت بقرارك — لن يُعاد التشغيل تلقائياً ---")
    except Exception:
        if not is_user_stopped():
            logger.exception("توقف غير متوقع — المشرف سيعيد التشغيل")
            raise
        print("--- 🛑 البوت متوقف ---")
