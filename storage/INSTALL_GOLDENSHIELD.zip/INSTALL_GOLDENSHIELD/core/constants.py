# الأطر الزمنية المعتمدة في النظام
TIMEFRAMES: tuple[str, ...] = ("15m", "1h", "4h")

TIMEFRAME_LABELS: dict[str, str] = {
    "15m": "M15",
    "1h": "H1",
    "4h": "H4",
}

# عتبات الجودة — مرحلة التجربة: الدخول من 75/100
SIGNAL_MIN_SCORE: float = 8.0
SIGNAL_MAX_SCORE: int = 10
SIGNAL_MIN_PERCENT: int = 75
SIGNAL_MAX_PERCENT: int = 100
# تلقائي من نفس عتبة التأهيل (مرحلة التجربة)
SIGNAL_AUTO_PERCENT: int = 75

# تحويل درجة 0–10 إلى نسبة 0–100 (8 = 75% — عتبة التجربة)
SCORE_PERCENT_MAP: dict[int, int] = {
    0: 0,
    1: 10,
    2: 20,
    3: 30,
    4: 40,
    5: 50,
    6: 60,
    7: 70,
    8: 75,
    9: 90,
    10: 100,
}


def score_to_percent(score: int | float) -> int:
    """تحويل درجة 0–10 إلى نسبة 0–100."""
    key = int(round(float(score)))
    return SCORE_PERCENT_MAP.get(key, 0)


def meets_signal_minimum(score: int | float) -> bool:
    """هل الدرجة تؤهل للدخول؟ (≥75/100)"""
    return score_to_percent(score) >= SIGNAL_MIN_PERCENT


def meets_auto_entry_minimum(score: int | float, auto_percent: int | None = None) -> bool:
    """هل الدرجة قوية بما يكفي لدخول تلقائي بدون زر؟"""
    threshold = SIGNAL_AUTO_PERCENT if auto_percent is None else int(auto_percent)
    return score_to_percent(score) >= threshold

# مؤشرات أساسية
SMA_PERIOD: int = 20
DEFAULT_OHLCV_LIMIT: int = 20

# اتصال (المرحلة 2+)
HEARTBEAT_TIMEOUT_SECONDS: int = 30

# فلاتر التنفيذ (المرحلة 3+)
MAX_SPREAD_PCT: float = 0.15
RSI_PERIOD: int = 14
ATR_PERIOD: int = 14
OHLCV_ANALYSIS_LIMIT: int = 50

# الذكاء الهجين (المرحلة 4+) — مرجع فقط؛ المصدر الفعلي: config/hybrid_params.yaml
NEWS_BLACKOUT_MINUTES: int = 5
VIX_THRESHOLD: float = 30.0
BONDS_YIELD_SPIKE_PCT: float = 3.0
FEAR_GREED_EXTREME_LOW: int = 20
FEAR_GREED_EXTREME_HIGH: int = 80
WHALE_WALL_MULTIPLIER: float = 3.0
SENTIMENT_ANOMALY_THRESHOLD: float = 2.0

# التنفيذ (المرحلة 5+) — قيم افتراضية؛ المصدر الفعلي: config/*.yaml عبر settings
DEFAULT_SL_PCT: float = 0.03
DEFAULT_RR_RATIO: float = 2.0
