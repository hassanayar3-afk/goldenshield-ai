@echo off
cd /d %~dp0
powershell -ExecutionPolicy Bypass -File deployment\register_autostart.ps1
pause
