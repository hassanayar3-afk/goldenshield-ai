"""قوالب لوحة تحكم Telegram — بطاقات تداول احترافية."""

from __future__ import annotations

import html
from dataclasses import dataclass
from datetime import date
from typing import TYPE_CHECKING

from config.settings import get_settings
from core.constants import (
    SIGNAL_MIN_PERCENT,
    meets_signal_minimum,
    score_to_percent,
)
from operations.message_templates import DIVIDER, _BRAND, _money, escape

if TYPE_CHECKING:
    from execution.models.trade import Position
    from risk.risk_orchestrator import RiskApproval, RiskOrchestrator
    from execution.trade_executor import TradeExecutor


@dataclass(frozen=True)
class RiskGrade:
    score: int
    icon: str
    label: str
    bar: str
    color_hint: str


def simple_signal_label(signal: str) -> str:
    mapping = {
        "BUY SIGNAL": "فرصة شراء",
        "WAIT": "انتظر",
        "REJECTED": "مرفوضة",
        "HALTED": "السوق متوقف",
        "HALT": "السوق متوقف",
    }
    return mapping.get(signal, signal)


def simple_strength_stars(score: int, *, maximum: int = 10) -> str:
    """شريط قوة — دوائر بدل النجوم."""
    percent = score_to_percent(score)
    filled = max(0, min(maximum, percent // 10))
    return "●" * filled + "○" * (maximum - filled)


def simple_strength_label(score: int) -> str:
    percent = score_to_percent(score)
    if percent >= SIGNAL_MIN_PERCENT:
        return "قوية جداً — جاهزة للدخول"
    if percent >= 70:
        return "جيدة — راقبها"
    if percent >= 50:
        return "متوسطة — لا تدخل الآن"
    return "ضعيفة — تجنب الدخول"


def risk_grade_from_score(score: int, *, signal: str = "WAIT") -> RiskGrade:
    percent = score_to_percent(score)
    if signal in {"HALTED", "HALT"}:
        return RiskGrade(score, "⛔", "السوق متوقف", "░░░░░", "halted")
    if signal == "REJECTED":
        return RiskGrade(score, "🚫", "مرفوضة", "█░░░░", "rejected")
    if percent >= SIGNAL_MIN_PERCENT:
        return RiskGrade(score, "🟢", "جاهزة للدخول", "█████", "low")
    if percent >= 70:
        return RiskGrade(score, "🟡", "راقبها", "████░", "medium")
    if percent >= 50:
        return RiskGrade(score, "🟠", "انتظر", "███░░", "moderate")
    return RiskGrade(score, "🔴", "ضعيفة", "██░░░", "high")


def format_entry_block_reason(
    *,
    signal: str,
    score: int,
    premium: bool,
    paused: bool,
    has_position: bool,
    approval_approved: bool,
    approval_reason: str = "",
) -> str:
    """رسالة بسيطة تشرح لماذا لا يظهر زر الدخول."""
    if paused:
        return "التداول موقوف — اضغط ▶️ تشغيل من القائمة الرئيسية."
    if has_position:
        return "لديك صفقة مفتوحة على هذه العملة — راجعها من 📂 مراكزي."
    if signal != "BUY SIGNAL":
        return f"السوق يقول «{simple_signal_label(signal)}» — ليس وقت شراء الآن."
    if not meets_signal_minimum(score):
        return (
            f"القوة {score_to_percent(score)}/100 — نحتاج {SIGNAL_MIN_PERCENT} على الأقل "
            f"ليظهر زر ✅ دخول الصفقة."
        )
    if not approval_approved:
        reason = approval_reason.strip() or "نظام الحماية يمنع الدخول حالياً."
        return f"🛡️ {reason}"
    if not premium:
        return "الإشارة لم تكتمل بعد — انتظر التحديث القادم."
    return ""


def _header(subtitle: str) -> str:
    return f"{_BRAND}\n{DIVIDER}\n<i>{escape(subtitle)}</i>"


def _pct_change(entry: float, target: float) -> str:
    if entry <= 0:
        return "0.00%"
    pct = ((target - entry) / entry) * 100
    sign = "+" if pct >= 0 else ""
    return f"{sign}{pct:.2f}%"


def format_main_dashboard(
    *,
    env: str,
    mode: str,
    balance: float,
    daily_pnl: str,
    open_count: int,
    paused: bool,
    kill_switch: str,
    pairs_count: int,
    manual_mode: bool = True,
) -> str:
    status = "موقوف ⏸️" if paused else "يعمل ✅"
    mode_note = "تجريبي" if mode.upper() == "PAPER" else "حقيقي"
    auto_pct = get_settings().auto_entry_min_percent
    if auto_pct <= SIGNAL_MIN_PERCENT:
        entry_note = "تلقائي ⚡"
        mode_hint = f"<i>⚡ دخول تلقائي لكل فرصة ≥ {SIGNAL_MIN_PERCENT}/100 (وضع الاختبار).</i>"
    else:
        entry_note = "مختلط ⚡🖐"
        mode_hint = (
            f"<i>⚡ تلقائي من {auto_pct}/100 — "
            f"🖐 يدوي من تيليجرام عند {SIGNAL_MIN_PERCENT}–{max(SIGNAL_MIN_PERCENT, auto_pct - 1)}/100.</i>"
        )
    return "\n".join(
        [
            _header("الرئيسية"),
            "",
            f"🤖 البوت <b>{status}</b>  |  وضع <b>{mode_note}</b>  |  دخول <b>{entry_note}</b>",
            "",
            f"💰 رصيدك: <b>{_money(balance)}</b>",
            f"📈 نتيجة اليوم: <b>{escape(daily_pnl)}</b>",
            f"📂 صفقات مفتوحة: <b>{open_count}</b>",
            "",
            f"📡 يراقب <b>{pairs_count}</b> عملات",
            "",
            mode_hint,
            "<i>اضغط 📡 الإشارات لمتابعة السوق.</i>",
        ]
    )


def _market_row(entry: dict) -> str:
    score = int(entry["score"])
    signal = str(entry["signal"])
    grade = risk_grade_from_score(score, signal=signal)
    coin = escape(entry["symbol"].split("/")[0])
    status = simple_signal_label(signal)
    percent = score_to_percent(score)
    return (
        f"{grade.icon} <b>{coin}</b> — {percent}/100\n"
        f"   {escape(status)} · {escape(simple_strength_label(score))}"
    )


def format_market_overview(all_entries: list[dict]) -> str:
    premium = [e for e in all_entries if e.get("premium")]
    watching = [e for e in all_entries if not e.get("premium")]

    lines = [
        _header("الإشارات"),
        "",
        "<i>ملخص بسيط — اضغط على العملة للتفاصيل</i>",
        "",
    ]

    if premium:
        lines.append("<b>🟢 جاهزة للدخول</b>")
        for entry in premium:
            lines.append(_market_row(entry))
        lines.append("")
    else:
        lines.append("🟢 <b>جاهزة للدخول:</b> لا توجد فرصة الآن")
        lines.append("")

    if watching:
        lines.append("<b>👁️ نراقبها</b>")
        for entry in watching:
            lines.append(_market_row(entry))
        lines.append("")
    elif not all_entries:
        lines.append("لا توجد بيانات بعد — انتظر دقيقة واحدة.")

    lines.append("<i>زر الدخول يظهر فقط في القسم الأخضر أعلاه.</i>")
    return "\n".join(lines).rstrip()


def format_watchlist_digest(all_entries: list[dict]) -> str:
    """ملخص سريع يُرسل عند التشغيل — كل العملات المراقبة."""
    return format_market_overview(all_entries)


def _line(icon: str, label: str, value: str, extra: str = "") -> str:
    """سطر واحد منظم ومحاذي: أيقونة + تسمية ثابتة العرض + قيمة."""
    label_pad = f"{label:<8}"
    base = f"│  {icon}  <code>{escape(label_pad)}</code>  <code>{value}</code>"
    if extra:
        return f"{base}  <code>{extra}</code>"
    return base


def format_trade_setup_card(
    *,
    symbol: str,
    price: float,
    score: int,
    signal: str,
    approval: RiskApproval | None = None,
    reasons: tuple[str, ...] | list[str] = (),
    prefs_label: str = "",
    risk_pct: float | None = None,
    can_enter: bool = False,
    entry_block_reason: str = "",
    balance: float | None = None,
) -> str:
    from risk.lot_calculator import LotCalculator

    settings = get_settings()
    grade = risk_grade_from_score(score, signal=signal)
    coin = escape(symbol.split("/")[0])
    percent = score_to_percent(score)
    used_risk = risk_pct if risk_pct is not None else settings.risk_per_trade_pct
    account = balance if balance is not None and balance > 0 else 10_000.0

    if approval is not None and approval.amount > 0 and approval.stop_loss > 0:
        entry = price
        sl = approval.stop_loss
        tp = approval.take_profit
        amount = approval.amount
    else:
        amount, sl, tp = LotCalculator(account).calculate(price, risk_pct=used_risk)
        entry = price
        if amount <= 0:
            sl = price * (1 - settings.default_sl_pct)
            tp = price * (1 + settings.default_sl_pct * settings.default_rr_ratio)

    points_risk = abs(entry - sl)
    points_profit = abs(tp - entry)
    risk_usdt = points_risk * amount if amount > 0 else account * (used_risk / 100.0)
    profit_usdt = (
        points_profit * amount
        if amount > 0
        else risk_usdt
        * (points_profit / points_risk if points_risk > 0 else settings.default_rr_ratio)
    )
    rr = (points_profit / points_risk) if points_risk > 0 else settings.default_rr_ratio
    status = "جاهزة للدخول ✅" if can_enter else simple_signal_label(signal)

    lines = [
        _BRAND,
        DIVIDER,
        f"<b>{coin}/USDT</b>  ·  شراء",
        "",
        f"{grade.icon}  <b>قوة الصفقة</b>  ·  <code>{percent}/100</code>",
        f"{simple_strength_stars(score)}",
        f"<i>{escape(simple_strength_label(score))}</i>",
        "",
        "┌─ <b>مستويات الصفقة</b>",
        _line("🎯", "Entry", f"{entry:,.2f}"),
        _line("🛑", "SL", f"{sl:,.2f}", _pct_change(entry, sl)),
        _line("💎", "TP", f"{tp:,.2f}", _pct_change(entry, tp)),
        "└────────────────",
        "",
        "┌─ <b>المخاطر والأرباح</b>",
        _line("⚠️", "الخطورة", f"{used_risk:.1f}%", f"{risk_usdt:,.2f} $"),
        _line("📉", "الخسارة", f"{points_risk:,.2f} نقطة", f"{risk_usdt:,.2f} $"),
        _line("📈", "الربح", f"+{points_profit:,.2f} نقطة", f"+{profit_usdt:,.2f} $"),
        _line("⚖️", "نسبة الهدف", f"+{profit_usdt:,.2f} $", f"1:{rr:.1f}"),
        "└────────────────",
        "",
        f"📌  <b>الحالة</b>  ·  {escape(status)}",
    ]

    auto_pct = settings.auto_entry_min_percent
    if can_enter and percent >= auto_pct:
        lines.append(
            f"<b>⚡ قد تُفتح تلقائياً</b> (قوة ≥ {auto_pct}/100) — أو اضغط الزر إن لم تُفتح بعد"
        )
    elif can_enter:
        lines.append(
            f"<b>➜ يدوي:</b> اضغط «دخول الصفقة الآن» "
            f"(التلقائي من {auto_pct}/100)"
        )
    elif entry_block_reason:
        lines.append(f"<i>{escape(entry_block_reason)}</i>")

    if reasons and can_enter:
        lines.append("")
        lines.append("📋 <b>أسباب الإشارة</b>")
        for reason in reasons[:2]:
            lines.append(f"• {escape(reason)}")

    return "\n".join(lines)


def format_position_card(
    position: Position,
    *,
    current_price: float,
    balance: float,
) -> str:
    if position.side.value == "buy":
        unrealized = (current_price - position.entry_price) * position.amount
        pnl_pct = (
            ((current_price - position.entry_price) / position.entry_price) * 100
            if position.entry_price > 0
            else 0.0
        )
    else:
        unrealized = (position.entry_price - current_price) * position.amount
        pnl_pct = (
            ((position.entry_price - current_price) / position.entry_price) * 100
            if position.entry_price > 0
            else 0.0
        )

    sign = "+" if unrealized >= 0 else ""
    pnl_icon = "🟢" if unrealized >= 0 else "🔴"
    coin = escape(position.symbol.split("/")[0])
    mode = "تجريبي" if position.is_paper else "حقيقي"
    risk_usdt = position.risk_per_unit * position.amount
    risk_pct_val = (risk_usdt / balance * 100) if balance > 0 else 0.0
    points_to_tp = abs(position.take_profit - position.entry_price)
    profit_at_tp = points_to_tp * position.amount
    points_risk = position.risk_per_unit
    rr = points_to_tp / points_risk if points_risk > 0 else 0.0
    be = "مفعّل" if position.breakeven_applied else "انتظار"
    partial = "تم" if position.partial_exit_done else "لا"
    opened = position.opened_at.strftime("%Y-%m-%d %H:%M") if position.opened_at else "—"

    return "\n".join(
        [
            _BRAND,
            DIVIDER,
            f"<b>{coin}/USDT</b>  ·  شراء  ·  {escape(mode)}",
            "",
            f"{pnl_icon}  <b>النتيجة الآن</b>  ·  "
            f"<code>{sign}{unrealized:,.2f} USDT</code>  ·  <code>{sign}{pnl_pct:.2f}%</code>",
            "",
            "┌─ <b>مستويات الصفقة</b>",
            _line("🎯", "Entry", f"{position.entry_price:,.2f}"),
            _line("📍", "Price", f"{current_price:,.2f}", _pct_change(position.entry_price, current_price)),
            _line("🛑", "SL", f"{position.stop_loss:,.2f}", _pct_change(position.entry_price, position.stop_loss)),
            _line("💎", "TP", f"{position.take_profit:,.2f}", _pct_change(position.entry_price, position.take_profit)),
            "└────────────────",
            "",
            "┌─ <b>المخاطر والأرباح</b>",
            _line("⚠️", "الخطورة", f"{risk_pct_val:.2f}%", f"{risk_usdt:,.2f} $"),
            _line("📉", "الخسارة", f"{points_risk:,.2f} نقطة", f"{risk_usdt:,.2f} $"),
            _line("📈", "الربح", f"+{points_to_tp:,.2f} نقطة", f"+{profit_at_tp:,.2f} $"),
            _line("⚖️", "نسبة الهدف", f"+{profit_at_tp:,.2f} $", f"1:{rr:.1f}"),
            "└────────────────",
            "",
            f"🔒 تعادل: <b>{be}</b>  ·  ✂️ جزئي: <b>{partial}</b>  ·  🕒 <code>{opened}</code>",
        ]
    )


def format_positions_list(
    positions: list[Position],
    prices: dict[str, float],
) -> str:
    lines = [_header("صفقاتي المفتوحة"), ""]
    if not positions:
        lines.append("لا توجد صفقات مفتوحة.")
        lines.append("")
        lines.append("راقب الفرص من 📡 الإشارات")
        return "\n".join(lines)

    for pos in positions:
        current = prices.get(pos.symbol, pos.entry_price)
        if pos.side.value == "buy":
            unrealized = (current - pos.entry_price) * pos.amount
        else:
            unrealized = (pos.entry_price - current) * pos.amount
        sign = "+" if unrealized >= 0 else ""
        icon = "🟢" if unrealized >= 0 else "🔴"
        coin = escape(pos.symbol.split("/")[0])
        lines.append(
            f"{icon} <b>{coin}</b> — {sign}{unrealized:,.2f} USDT\n"
            f"   دخلت {pos.entry_price:,.2f} → الآن {current:,.2f}\n"
            f"   SL {pos.stop_loss:,.2f}  |  TP {pos.take_profit:,.2f}"
        )
        lines.append("")
    lines.append("اضغط على الصفقة لعرض التفاصيل الكاملة 👇")
    return "\n".join(lines).rstrip()


def format_action_result(title: str, detail: str) -> str:
    return "\n".join([_header(title), "", escape(detail)])
