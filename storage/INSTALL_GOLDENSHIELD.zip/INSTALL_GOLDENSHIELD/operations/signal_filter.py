"""فلتر الإشارات — فقط ما يؤهل للدخول حسب دستور GoldenShield."""

from __future__ import annotations

from typing import TYPE_CHECKING

from core.constants import meets_signal_minimum

if TYPE_CHECKING:
    from audit.consensus_gate import ConsensusResult
    from core.analyzer import AnalysisResult
    from risk.risk_orchestrator import RiskApproval


def is_premium_trade_signal(
    result: AnalysisResult,
    *,
    consensus: ConsensusResult | None = None,
    risk_approval: RiskApproval | None = None,
) -> bool:
    """إشارة مؤهلة = BUY + درجة ≥75% + Shadow + مخاطر — لا WAIT ولا ضعيف."""
    if result.halted:
        return False
    if result.signal != "BUY SIGNAL":
        return False
    if not result.passed or not meets_signal_minimum(result.score):
        return False
    if consensus is not None and not consensus.approved:
        return False
    if risk_approval is not None and not risk_approval.approved:
        return False
    return True
