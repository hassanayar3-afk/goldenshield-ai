"""أوامر Telegram — لوحة تداول تفاعلية."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

import requests

from config.settings import get_settings
from operations.bot_admin import can_control_bot
from operations.message_templates import format_help_message
from operations.shutdown_guard import is_user_stopped, should_block_signals
from operations.telegram_admin import handle_admin_command
from operations.telegram_bot import TelegramBot
from operations.telegram_dashboard import TelegramDashboard
from operations.symbol_registry import get_symbol_registry

if TYPE_CHECKING:
    from audit.audit_trail import AuditTrail
    from execution.trade_executor import TradeExecutor
    from operations.panic_button import PanicButton
    from operations.runtime_state import OperationsRuntime
    from risk.risk_orchestrator import RiskOrchestrator

logger = logging.getLogger(__name__)


class TelegramCommandHandler:
    def __init__(
        self,
        *,
        runtime: OperationsRuntime,
        executor: TradeExecutor,
        risk: RiskOrchestrator,
        panic: PanicButton,
        audit: AuditTrail | None = None,
        telegram: TelegramBot | None = None,
        price_fetcher=None,
    ) -> None:
        self.runtime = runtime
        self.executor = executor
        self.risk = risk
        self.panic = panic
        self.audit = audit
        self.telegram = telegram or TelegramBot()
        self.dashboard = TelegramDashboard(
            runtime=runtime,
            executor=executor,
            risk=risk,
            panic=panic,
            audit=audit,
            telegram=self.telegram,
            price_fetcher=price_fetcher,
        )
        self._price_fetcher = price_fetcher
        self._offset: int | None = None
        settings = get_settings()
        self._enabled = bool(settings.telegram_token and settings.telegram_chat_id)
        self._updates_url = (
            f"https://api.telegram.org/bot{settings.telegram_token}/getUpdates"
            if settings.telegram_token
            else None
        )

    @property
    def enabled(self) -> bool:
        return self._enabled

    def update_market_snapshot(
        self,
        entries: list[dict],
        prices: dict[str, float] | None = None,
        *,
        reasons: dict[str, tuple[str, ...]] | None = None,
    ) -> None:
        self.dashboard.update_market(entries, prices, reasons=reasons)

    def send_trade_opportunity(
        self,
        symbol: str,
        entry: dict,
        *,
        reasons: tuple[str, ...] = (),
    ) -> None:
        if should_block_signals() or self.runtime.user_stopped:
            return
        view = self.dashboard.build_trade_alert(symbol, entry, reasons)
        self.telegram.send_message(view.text, reply_markup=view.keyboard)

    def send_watchlist_digest(self) -> None:
        view = self.dashboard.render_watchlist_digest()
        if view is None:
            return
        self.telegram.send_message(view.text, reply_markup=view.keyboard)

    def handle(self, command: str) -> tuple[str, dict | None]:
        admin_reply = handle_admin_command(command)
        if admin_reply is not None:
            return admin_reply, self.dashboard.render_main().keyboard

        cmd = command.strip().lower().split()[0]

        if cmd in {"/start", "/menu", "/dashboard", "start", "menu", "dashboard"}:
            view = self.dashboard.render_main()
            return view.text, view.keyboard

        if cmd in {"/market", "market"}:
            view = self.dashboard.render_market()
            return view.text, view.keyboard

        if cmd in {"/positions", "positions"}:
            view = self.dashboard.render_positions()
            return view.text, view.keyboard

        if cmd in {"/pause", "pause"}:
            self.runtime.pause()
            view = self.dashboard.render_main()
            return view.text, view.keyboard

        if cmd in {"/resume", "resume"}:
            if self.runtime.user_stopped or is_user_stopped():
                return (
                    "⛔ البوت متوقف بقرارك. شغّل <b>00_START.bat</b> على السيرفر للعودة.",
                    self.dashboard.render_main().keyboard,
                )
            self.runtime.resume()
            view = self.dashboard.render_main()
            return view.text, view.keyboard

        if cmd in {"/panic", "panic"}:
            self.runtime.stop_permanently(reason="telegram_panic")
            symbols = list(self.executor.position_manager.open_symbols())
            prices = self._fetch_prices(symbols) if symbols else {}
            result = self.panic.trigger(prices, reason="أمر Telegram /panic")
            view = self.dashboard.render_main()
            return (
                f"{view.text}\n\n🚨 {result.message}\n\n"
                "⛔ <b>إيقاف كامل</b> — لن تُرسل إشارات ولن يُعاد التشغيل تلقائياً.",
                view.keyboard,
            )

        if cmd in {"/stop", "stop"}:
            self.runtime.stop_permanently(reason="telegram_stop")
            view = self.dashboard.render_main()
            return (
                f"{view.text}\n\n⛔ <b>تم الإيقاف الكامل</b> — لا إشارات ولا إعادة تشغيل تلقائي.",
                view.keyboard,
            )

        return format_help_message(), self.dashboard.render_main().keyboard

    def _process_callback(self, callback: dict) -> bool:
        callback_id = callback.get("id", "")
        data = str(callback.get("data", ""))
        message = callback.get("message") or {}
        message_id = message.get("message_id")
        chat = message.get("chat") or {}
        chat_id = str(chat.get("id", ""))
        settings = get_settings()

        if chat_id != str(settings.telegram_chat_id) and not can_control_bot(chat_id):
            self.telegram.answer_callback_query(callback_id, "غير مصرح")
            return False

        view = self.dashboard.handle_callback(data)
        ok = False
        if isinstance(message_id, int):
            ok = self.telegram.edit_message_text(
                message_id,
                view.text,
                reply_markup=view.keyboard,
            )
        if not ok:
            self.telegram.send_message(view.text, reply_markup=view.keyboard)

        self.telegram.answer_callback_query(callback_id, "تم ✓")
        return True

    def poll_once(self) -> int:
        if not self._enabled or not self._updates_url:
            return 0

        params: dict[str, int] = {"timeout": 0}
        if self._offset is not None:
            params["offset"] = self._offset

        try:
            response = requests.get(self._updates_url, params=params, timeout=10)
            if response.status_code != 200:
                return 0
            payload = response.json()
        except Exception as exc:
            logger.debug("فشل poll Telegram: %s", exc)
            return 0

        updates = payload.get("result", [])
        processed = 0
        settings = get_settings()

        for update in updates:
            update_id = update.get("update_id")
            if isinstance(update_id, int):
                self._offset = update_id + 1

            callback = update.get("callback_query")
            if callback:
                if self._process_callback(callback):
                    processed += 1
                continue

            message = update.get("message") or {}
            chat = message.get("chat") or {}
            chat_id = str(chat.get("id", ""))
            if chat_id != str(settings.telegram_chat_id) and not can_control_bot(chat_id):
                continue

            text = message.get("text", "")
            if not text.startswith("/"):
                continue

            reply, keyboard = self.handle(text)
            self.telegram.send_message(reply, reply_markup=keyboard)
            processed += 1

        return processed

    async def poll_loop(self, interval_seconds: float = 3.0) -> None:
        while True:
            try:
                self.poll_once()
            except Exception as exc:
                logger.warning("خطأ في حلقة Telegram: %s", exc)
            await asyncio.sleep(interval_seconds)

    def _fetch_prices(self, symbols: list[str]) -> dict[str, float]:
        if self._price_fetcher is None:
            return {}
        return self._price_fetcher(symbols)
