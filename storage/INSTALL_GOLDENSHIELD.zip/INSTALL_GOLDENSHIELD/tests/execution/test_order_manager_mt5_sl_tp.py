"""اختبارات تمرير SL/TP إلى MT5."""

from __future__ import annotations

from core.exceptions import ExecutionError
from execution.models.order import OrderSide
from execution.mt5_bridge import MT5OrderResult
from execution.order_manager import OrderManager


class _Settings:
    execution_mode = "live"
    execution_backend = "mt5"
    mt5_enabled = True
    mt5_attach_sl_tp = True


def test_mt5_order_passes_sl_tp(monkeypatch):
    calls: list[dict] = []

    class Bridge:
        def place_market(self, symbol, *, side, amount, stop_loss=None, take_profit=None):
            calls.append(
                {
                    "symbol": symbol,
                    "side": side,
                    "amount": amount,
                    "stop_loss": stop_loss,
                    "take_profit": take_profit,
                }
            )
            return MT5OrderResult(ticket=99, symbol="BTCUSD", volume=0.1, price=50000.0, retcode=0)

        def modify_position_sl_tp(self, *args, **kwargs):
            raise AssertionError("should not modify when attach succeeds")

    monkeypatch.setattr("execution.order_manager.get_settings", lambda: _Settings())
    monkeypatch.setattr("execution.mt5_bridge.get_mt5_bridge", lambda: Bridge())

    manager = OrderManager()
    order = manager.create_market_order(
        "BTC/USDT",
        OrderSide.BUY,
        0.01,
        reference_price=50000.0,
        stop_loss=49000.0,
        take_profit=52000.0,
    )

    assert order.status.value == "filled"
    assert calls[0]["stop_loss"] == 49000.0
    assert calls[0]["take_profit"] == 52000.0


def test_mt5_order_fallback_modify_sl_tp(monkeypatch):
    modify_calls: list[dict] = []
    place_calls = 0

    class Bridge:
        def place_market(self, symbol, *, side, amount, stop_loss=None, take_profit=None):
            nonlocal place_calls
            place_calls += 1
            if stop_loss is not None or take_profit is not None:
                raise ExecutionError("invalid stops")
            return MT5OrderResult(ticket=100, symbol="BTCUSD", volume=0.1, price=50000.0, retcode=0)

        def modify_position_sl_tp(self, symbol, *, stop_loss=None, take_profit=None):
            modify_calls.append(
                {"symbol": symbol, "stop_loss": stop_loss, "take_profit": take_profit}
            )
            return True

    monkeypatch.setattr("execution.order_manager.get_settings", lambda: _Settings())
    monkeypatch.setattr("execution.mt5_bridge.get_mt5_bridge", lambda: Bridge())

    manager = OrderManager()
    order = manager.create_market_order(
        "BTC/USDT",
        OrderSide.BUY,
        0.01,
        reference_price=50000.0,
        stop_loss=49000.0,
        take_profit=52000.0,
    )

    assert order.status.value == "filled"
    assert place_calls == 2
    assert modify_calls == [{"symbol": "BTC/USDT", "stop_loss": 49000.0, "take_profit": 52000.0}]


def test_mt5_skips_sl_tp_when_disabled(monkeypatch):
    class S(_Settings):
        mt5_attach_sl_tp = False

    captured: dict = {}

    class Bridge:
        def place_market(self, symbol, *, side, amount, stop_loss=None, take_profit=None):
            captured["stop_loss"] = stop_loss
            captured["take_profit"] = take_profit
            return MT5OrderResult(ticket=1, symbol="BTCUSD", volume=0.1, price=1.0, retcode=0)

    monkeypatch.setattr("execution.order_manager.get_settings", lambda: S())
    monkeypatch.setattr("execution.mt5_bridge.get_mt5_bridge", lambda: Bridge())

    OrderManager().create_market_order(
        "BTC/USDT",
        OrderSide.BUY,
        0.01,
        reference_price=1.0,
        stop_loss=0.9,
        take_profit=1.2,
    )

    assert captured["stop_loss"] is None
    assert captured["take_profit"] is None
