from core.constants import meets_auto_entry_minimum, score_to_percent


def test_score_percent_map_for_auto_band() -> None:
    assert score_to_percent(8) == 75
    assert score_to_percent(9) == 90
    assert score_to_percent(10) == 100


def test_auto_entry_default_threshold() -> None:
    assert meets_auto_entry_minimum(8)
    assert meets_auto_entry_minimum(9)
    assert meets_auto_entry_minimum(10)


def test_auto_entry_custom_threshold() -> None:
    assert not meets_auto_entry_minimum(8, auto_percent=90)
    assert meets_auto_entry_minimum(9, auto_percent=90)
    assert not meets_auto_entry_minimum(9, auto_percent=95)
    assert meets_auto_entry_minimum(10, auto_percent=95)
