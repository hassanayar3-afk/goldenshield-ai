import paramiko

c = paramiko.SSHClient()
c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect(
    "169.58.8.253",
    username="root",
    password="AsF37xgQ70up3i",
    timeout=25,
    allow_agent=False,
    look_for_keys=False,
)
cmd = (
    "CRON_LINE='*/5 * * * * /opt/goldenshield/deployment/run_infrastructure_watchdog.sh'; "
    "( crontab -l 2>/dev/null | grep -v run_infrastructure_watchdog ; echo \"$CRON_LINE\" ) | crontab -; "
    "crontab -l"
)
_, o, _ = c.exec_command(cmd, timeout=30)
print(o.read().decode())
c.close()
