"""إعادة إرسال حزمة أوضح للمبتدئ عبر تيليجرام."""

from __future__ import annotations

import os
import zipfile
from pathlib import Path

import requests
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
EXCLUDE = {".venv", "__pycache__", ".git", ".pytest_cache", ".mypy_cache", ".cursor", "htmlcov"}
EXCLUDE_SUF = {".pyc", ".pyo", ".log"}


def main() -> int:
    load_dotenv(ROOT / ".env", override=True)
    token = os.getenv("TELEGRAM_TOKEN")
    chat = os.getenv("TELEGRAM_CHAT_ID")
    assert token and chat

    local: dict[str, str] = {}
    for line in (ROOT / ".env").read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        local[k.strip()] = v.strip()

    env_txt = "\n".join(
        [
            "ENV=production",
            "EXECUTION_MODE=live",
            "EXECUTION_BACKEND=mt5",
            "MT5_ENABLED=true",
            f"MT5_LOGIN={local.get('MT5_LOGIN', '345814054')}",
            f"MT5_PASSWORD={local.get('MT5_PASSWORD', '')}",
            f"MT5_SERVER={local.get('MT5_SERVER', 'XMGlobal-MT5 10')}",
            "MT5_BROKER=XM",
            "TELEGRAM_SEND_CYCLE_SIGNALS=false",
            "TELEGRAM_SIGNALS_ONLY=true",
            "LOOP_INTERVAL_SECONDS=15",
            "MANUAL_ENTRY_REQUIRED=false",
            "AUTO_ENTRY_MIN_PERCENT=75",
            "TRIAL_MODE=true",
            "TRIAL_JOURNAL_ENABLED=true",
            "MT5_ATTACH_SL_TP=true",
            "BOT_ADMIN_FULL_ACCESS=true",
            "BOT_AUTO_SYNC_MT5=true",
            f"TELEGRAM_TOKEN={local.get('TELEGRAM_TOKEN', '')}",
            f"TELEGRAM_BOT_USERNAME={local.get('TELEGRAM_BOT_USERNAME', 'GoldenShield_2026_bot')}",
            f"TELEGRAM_CHAT_ID={local.get('TELEGRAM_CHAT_ID', '')}",
            f"TELEGRAM_BACKUP_CHANNEL_ID={local.get('TELEGRAM_BACKUP_CHANNEL_ID', '-1004462420308')}",
            "DB_PATH=storage/db/goldenshield.db",
        ]
    ) + "\n"

    bat = (
        "@echo off\r\n"
        "title GoldenShield Supervisor\r\n"
        "cd /d %~dp0\r\n"
        "set PYTHONIOENCODING=utf-8\r\n"
        "echo === GoldenShield - auto restart ===\r\n"
        "echo Network crash = auto restart | Full stop = 00_STOP.bat or /panic\r\n"
        "py -m pip install -r requirements.txt MetaTrader5 -q 2>nul\r\n"
        "if not exist storage\\db\\backups mkdir storage\\db\\backups\r\n"
        "if not exist storage\\logs mkdir storage\\logs\r\n"
        "if not exist storage\\runtime mkdir storage\\runtime\r\n"
        "py scripts\\bootstrap_storage.py\r\n"
        "py scripts\\lifecycle.py clear-stop\r\n"
        ":loop\r\n"
        "if exist storage\\runtime\\user_stopped.flag (\r\n"
        "  echo [STOP] Stopped by you - no auto restart.\r\n"
        "  pause\r\n"
        "  exit /b 0\r\n"
        ")\r\n"
        "echo Keep MetaTrader5 OPEN and logged in.\r\n"
        "py -u main.py\r\n"
        "if exist storage\\runtime\\user_stopped.flag (\r\n"
        "  echo [STOP] Stopped by you.\r\n"
        "  pause\r\n"
        "  exit /b 0\r\n"
        ")\r\n"
        "echo Restarting in 15 seconds...\r\n"
        "timeout /t 15 /nobreak\r\n"
        "goto loop\r\n"
    )

    stop_bat = (
        "@echo off\r\n"
        "cd /d %~dp0\r\n"
        "py scripts\\lifecycle.py request-stop manual_stop\r\n"
        "echo Stopped. No signals. No auto restart.\r\n"
        "pause\r\n"
    )

    readme = (
        "IQRAA HUNAA / اقرأ هنا\r\n"
        "1) Extract All this zip INTO Downloads (default is OK)\r\n"
        "2) Open the new folder INSTALL_GOLDENSHIELD\r\n"
        "3) Double-click: 00_START.bat (auto-restart on network issues)\r\n"
        "4) One-time: INSTALL_AUTOSTART.bat as Admin = start with Windows\r\n"
        "5) Full stop: 00_STOP.bat or Telegram /panic\r\n"
        "6) MetaTrader5 opens automatically if installed in default path\r\n"
    )

    zip_path = ROOT / "storage" / "INSTALL_GOLDENSHIELD.zip"
    if zip_path.exists():
        zip_path.unlink()

    prefix = "INSTALL_GOLDENSHIELD/"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in ROOT.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(ROOT)
            if set(rel.parts) & EXCLUDE:
                continue
            if rel.suffix in EXCLUDE_SUF:
                continue
            if rel.name == ".env":
                continue
            if "storage" in rel.parts and rel.suffix in {".db", ".zip"}:
                continue
            zf.write(path, prefix + str(rel).replace("\\", "/"))
        zf.writestr(prefix + ".env", env_txt)
        zf.writestr(prefix + "00_START.bat", bat)
        zf.writestr(prefix + "00_STOP.bat", stop_bat)
        zf.writestr(prefix + "INSTALL_AUTOSTART.bat", (
            "@echo off\r\n"
            "cd /d %~dp0\r\n"
            "powershell -ExecutionPolicy Bypass -File deployment\\register_autostart.ps1\r\n"
            "pause\r\n"
        ))
        zf.writestr(prefix + "00_IQRAA.txt", readme)

    caption = (
        "🛡️ مرحلة التجربة — GoldenShield\n"
        "دخول تلقائي من 75/100 | صلاحيات إدارية كاملة\n"
        "عملات + أسهم + فوركس | SL/TP على MT5\n\n"
        "1) حمّل الزيب واستخرجه على السيرفر\n"
        "2) أوقف التشغيل القديم ثم 00_START.bat\n"
        "3) MT5 مفتوح ومسجّل دخول"
    )
    with zip_path.open("rb") as fh:
        data = requests.post(
            f"https://api.telegram.org/bot{token}/sendDocument",
            data={"chat_id": chat, "caption": caption},
            files={"document": ("INSTALL_GOLDENSHIELD.zip", fh)},
            timeout=180,
        ).json()
    print(data.get("ok"), data.get("description", "ok"), zip_path.stat().st_size)
    return 0 if data.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
