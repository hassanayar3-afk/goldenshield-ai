@echo off
title GoldenShield Supervisor
cd /d %~dp0
set PYTHONIOENCODING=utf-8
echo === GoldenShield - auto restart ===
echo Network crash = auto restart | Full stop = 00_STOP.bat or /panic
py -m pip install -r requirements.txt MetaTrader5 -q 2>nul
if not exist storage\db\backups mkdir storage\db\backups
if not exist storage\logs mkdir storage\logs
if not exist storage\runtime mkdir storage\runtime
py scripts\bootstrap_storage.py
py scripts\lifecycle.py clear-stop
:loop
if exist storage\runtime\user_stopped.flag (
  echo [STOP] Stopped by you - no auto restart.
  pause
  exit /b 0
)
echo Keep MetaTrader5 OPEN and logged in.
py -u main.py
if exist storage\runtime\user_stopped.flag (
  echo [STOP] Stopped by you.
  pause
  exit /b 0
)
echo Restarting in 15 seconds...
timeout /t 15 /nobreak
goto loop
