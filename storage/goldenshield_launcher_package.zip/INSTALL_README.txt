GoldenShield launcher package

1. Copy these files into C:\GoldenShield_Binance\
2. Keep your existing project files and .env as-is.
3. Run START_BOT.bat to start the bot.
4. Use REST_BOT.bat to restart.
5. Use STOP_BOT.bat to stop.
6. Use BOT_WINDOW.bat to watch live signals.
