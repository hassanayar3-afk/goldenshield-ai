"""إنشاء وإلغاء وتعديل الأوامر."""

from __future__ import annotations

import logging

from config.settings import get_settings
from core.exceptions import ExecutionError
from data.exchange_client import get_exchange
from execution.models.order import Order, OrderSide, OrderStatus, OrderType

logger = logging.getLogger(__name__)


class OrderManager:
    def __init__(self) -> None:
        self._orders: dict[str, Order] = {}

    @property
    def orders(self) -> list[Order]:
        return list(self._orders.values())

    def create_market_order(
        self,
        symbol: str,
        side: OrderSide,
        amount: float,
        *,
        reference_price: float,
    ) -> Order:
        if amount <= 0:
            raise ExecutionError(f"حجم الأمر غير صالح: {amount}")

        settings = get_settings()
        order = Order(
            symbol=symbol,
            side=side,
            amount=round(amount, 8),
            order_type=OrderType.MARKET,
            price=reference_price,
            is_paper=settings.execution_mode != "live",
        )
        self._orders[order.id] = order

        if settings.execution_mode == "live":
            self._submit_live_order(order)
        else:
            order.mark_filled(reference_price)

        return order

    def _submit_live_order(self, order: Order) -> None:
        settings = get_settings()
        backend = settings.execution_backend
        if settings.mt5_enabled or backend == "mt5":
            self._submit_mt5_order(order)
            return

        if not settings.binance_api_key or not settings.binance_api_secret:
            order.mark_rejected()
            raise ExecutionError("مفاتيح Binance مطلوبة للتنفيذ الحي (أو فعّل MT5)")

        exchange = get_exchange()
        try:
            ccxt_side = order.side.value
            if order.order_type == OrderType.MARKET:
                result = exchange.create_order(
                    order.symbol,
                    "market",
                    ccxt_side,
                    order.amount,
                )
            else:
                result = exchange.create_order(
                    order.symbol,
                    "limit",
                    ccxt_side,
                    order.amount,
                    order.price,
                )
            order.id = str(result.get("id", order.id))
            fill_price = float(result.get("average") or result.get("price") or order.price or 0)
            order.mark_filled(fill_price)
        except Exception as exc:
            order.mark_rejected()
            logger.exception("فشل تنفيذ الأمر الحي")
            raise ExecutionError(f"فشل تنفيذ الأمر: {exc}") from exc

    def _submit_mt5_order(self, order: Order) -> None:
        from execution.mt5_bridge import get_mt5_bridge

        bridge = get_mt5_bridge()
        try:
            result = bridge.place_market(
                order.symbol,
                side=order.side.value,
                amount=order.amount,
            )
            order.id = f"mt5-{result.ticket}"
            order.mark_filled(result.price)
            logger.info(
                "MT5 filled %s %s vol=%s @ %s ticket=%s",
                order.side.value,
                result.symbol,
                result.volume,
                result.price,
                result.ticket,
            )
        except Exception as exc:
            order.mark_rejected()
            logger.exception("فشل تنفيذ أمر MT5")
            raise ExecutionError(f"فشل أمر MT5: {exc}") from exc

    def cancel_order(self, order_id: str) -> bool:
        order = self._orders.get(order_id)
        if order is None or not order.is_active:
            return False

        settings = get_settings()
        if settings.execution_mode == "live":
            exchange = get_exchange()
            try:
                exchange.cancel_order(order_id, order.symbol)
            except Exception as exc:
                raise ExecutionError(f"فشل إلغاء الأمر: {exc}") from exc

        order.mark_cancelled()
        return True

    def modify_order(
        self,
        order_id: str,
        *,
        amount: float | None = None,
        price: float | None = None,
    ) -> Order:
        order = self._orders.get(order_id)
        if order is None:
            raise ExecutionError(f"الأمر غير موجود: {order_id}")
        if order.status == OrderStatus.FILLED:
            raise ExecutionError("لا يمكن تعديل أمر منفّذ")
        if order.status in {OrderStatus.CANCELLED, OrderStatus.REJECTED}:
            raise ExecutionError(f"لا يمكن تعديل أمر بحالة {order.status.value}")

        if amount is not None:
            if amount <= 0:
                raise ExecutionError(f"حجم الأمر غير صالح: {amount}")
            order.amount = round(amount, 8)

        if price is not None:
            if price <= 0:
                raise ExecutionError(f"سعر الأمر غير صالح: {price}")
            order.price = price
            order.order_type = OrderType.LIMIT

        settings = get_settings()
        if settings.execution_mode == "live" and order.is_active:
            exchange = get_exchange()
            try:
                params: dict = {}
                if amount is not None:
                    params["amount"] = order.amount
                if price is not None:
                    params["price"] = order.price
                exchange.edit_order(
                    order_id,
                    order.symbol,
                    order.order_type.value,
                    order.side.value,
                    order.amount,
                    order.price,
                    params,
                )
            except Exception as exc:
                raise ExecutionError(f"فشل تعديل الأمر: {exc}") from exc

        return order

    def get_order(self, order_id: str) -> Order | None:
        return self._orders.get(order_id)

    def clear(self) -> None:
        self._orders.clear()
