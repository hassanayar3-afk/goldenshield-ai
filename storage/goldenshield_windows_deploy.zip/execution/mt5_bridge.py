"""جسر MetaTrader 5 (XM) — يعمل فقط على Windows مع طرفية MT5 مفتوحة."""

from __future__ import annotations

import logging
import sys
from dataclasses import dataclass
from typing import Any

from config.settings import get_settings
from core.exceptions import ExecutionError

logger = logging.getLogger(__name__)

# رموز المشروع (Binance) → رموز شائعة على XM MT5
DEFAULT_SYMBOL_MAP: dict[str, str] = {
    "BTC/USDT": "BTCUSD",
    "ETH/USDT": "ETHUSD",
    "BNB/USDT": "BNBUSD",
    "SOL/USDT": "SOLUSD",
    "XRP/USDT": "XRPUSD",
    "ADA/USDT": "ADAUSD",
    "LINK/USDT": "LINKUSD",
    "AVAX/USDT": "AVAXUSD",
}


@dataclass(frozen=True)
class MT5OrderResult:
    ticket: int
    symbol: str
    volume: float
    price: float
    retcode: int


def is_windows() -> bool:
    return sys.platform.startswith("win")


def map_symbol(binance_symbol: str) -> str:
    return DEFAULT_SYMBOL_MAP.get(binance_symbol, binance_symbol.replace("/", ""))


class MT5Bridge:
    """واجهة رفيعة حول حزمة MetaTrader5."""

    def __init__(self) -> None:
        self._mt5: Any | None = None
        self._connected = False

    @property
    def connected(self) -> bool:
        return self._connected

    def _import_mt5(self) -> Any:
        if not is_windows():
            raise ExecutionError(
                "MetaTrader5 يتطلب Windows + طرفية MT5. Contabo الحالي Linux — اشترِ Windows VPS."
            )
        try:
            import MetaTrader5 as mt5  # type: ignore
        except ImportError as exc:
            raise ExecutionError(
                "حزمة MetaTrader5 غير مثبتة. على Windows: pip install MetaTrader5"
            ) from exc
        return mt5

    def connect(self) -> None:
        settings = get_settings()
        if not settings.mt5_enabled:
            raise ExecutionError("MT5_ENABLED=false — لم يُفعَّل الربط بعد")
        if not settings.mt5_login or not settings.mt5_password or not settings.mt5_server:
            raise ExecutionError("أكمل MT5_LOGIN و MT5_PASSWORD و MT5_SERVER في .env")

        mt5 = self._import_mt5()
        if not mt5.initialize():
            raise ExecutionError(f"فشل تشغيل طرفية MT5: {mt5.last_error()}")

        authorized = mt5.login(
            int(settings.mt5_login),
            password=settings.mt5_password,
            server=settings.mt5_server,
        )
        if not authorized:
            err = mt5.last_error()
            mt5.shutdown()
            raise ExecutionError(f"فشل تسجيل دخول XM/MT5: {err}")

        self._mt5 = mt5
        self._connected = True
        info = mt5.account_info()
        logger.info(
            "MT5 connected | login=%s server=%s balance=%s",
            settings.mt5_login,
            settings.mt5_server,
            getattr(info, "balance", "?"),
        )

    def ensure_connected(self) -> Any:
        if not self._connected or self._mt5 is None:
            self.connect()
        assert self._mt5 is not None
        return self._mt5

    def shutdown(self) -> None:
        if self._mt5 is not None:
            try:
                self._mt5.shutdown()
            except Exception:
                logger.exception("MT5 shutdown error")
        self._mt5 = None
        self._connected = False

    def account_balance(self) -> float:
        mt5 = self.ensure_connected()
        info = mt5.account_info()
        if info is None:
            raise ExecutionError(f"تعذر قراءة رصيد MT5: {mt5.last_error()}")
        return float(info.balance)

    def resolve_symbol(self, binance_symbol: str) -> str:
        mt5 = self.ensure_connected()
        candidate = map_symbol(binance_symbol)
        info = mt5.symbol_info(candidate)
        if info is None:
            # محاولة إظهار الرمز في Market Watch
            if not mt5.symbol_select(candidate, True):
                raise ExecutionError(f"رمز MT5 غير موجود: {candidate} (من {binance_symbol})")
            info = mt5.symbol_info(candidate)
        if info is None:
            raise ExecutionError(f"تعذر تحميل معلومات الرمز: {candidate}")
        if not info.visible:
            mt5.symbol_select(candidate, True)
        return candidate

    def volume_from_amount(self, mt5_symbol: str, amount: float) -> float:
        """يحول كمية العملة تقريباً إلى لوت حسب volume_step."""
        mt5 = self.ensure_connected()
        info = mt5.symbol_info(mt5_symbol)
        if info is None:
            raise ExecutionError(f"لا معلومات حجم لـ {mt5_symbol}")
        step = float(info.volume_step or 0.01)
        vmin = float(info.volume_min or step)
        vmax = float(info.volume_max or 100.0)
        # amount عندنا بوحدات الأصل؛ على CFD غالباً 1 lot ≈ عقد محدد — نقرّب بلطف
        volume = max(vmin, round(amount / max(step, 1e-8)) * step)
        # إن كانت الكمية صغيرة جداً استخدم الحد الأدنى
        if amount > 0 and volume < vmin:
            volume = vmin
        volume = min(max(volume, vmin), vmax)
        # تقريب لعدد منازل الخطوة
        decimals = max(0, str(step)[::-1].find("."))
        return round(volume, decimals if decimals > 0 else 2)

    def place_market(
        self,
        binance_symbol: str,
        *,
        side: str,
        amount: float,
        stop_loss: float | None = None,
        take_profit: float | None = None,
    ) -> MT5OrderResult:
        mt5 = self.ensure_connected()
        symbol = self.resolve_symbol(binance_symbol)
        volume = self.volume_from_amount(symbol, amount)
        tick = mt5.symbol_info_tick(symbol)
        if tick is None:
            raise ExecutionError(f"لا سعر حي لـ {symbol}")

        is_buy = side.lower() in {"buy", "long"}
        order_type = mt5.ORDER_TYPE_BUY if is_buy else mt5.ORDER_TYPE_SELL
        price = float(tick.ask if is_buy else tick.bid)

        request: dict[str, Any] = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": volume,
            "type": order_type,
            "price": price,
            "deviation": 30,
            "magic": 20260714,
            "comment": "GoldenShield",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        if stop_loss is not None and stop_loss > 0:
            request["sl"] = float(stop_loss)
        if take_profit is not None and take_profit > 0:
            request["tp"] = float(take_profit)

        result = mt5.order_send(request)
        if result is None:
            raise ExecutionError(f"order_send فشل: {mt5.last_error()}")
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            raise ExecutionError(
                f"رفض MT5 الأمر retcode={result.retcode} comment={getattr(result, 'comment', '')}"
            )
        fill = float(result.price or price)
        return MT5OrderResult(
            ticket=int(result.order or result.deal or 0),
            symbol=symbol,
            volume=volume,
            price=fill,
            retcode=int(result.retcode),
        )


_bridge: MT5Bridge | None = None


def get_mt5_bridge() -> MT5Bridge:
    global _bridge
    if _bridge is None:
        _bridge = MT5Bridge()
    return _bridge
