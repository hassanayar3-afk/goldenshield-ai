"""منسق التنفيذ الرئيسي."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from config.settings import get_settings
from core.analyzer import AnalysisResult
from core.constants import meets_signal_minimum
from core.exceptions import ExecutionError
from data.exchange_client import get_exchange
from execution.breakeven_logic import BreakevenAction, evaluate_breakeven
from execution.correlation_filter import CorrelationFilter
from execution.dark_pool_splitter import split_order
from execution.emergency_flat import emergency_flat
from execution.models.order import OrderSide
from execution.models.trade import ExecutionResult, Position
from execution.mutex_guard import MutexGuard
from execution.order_manager import OrderManager
from execution.position_manager import PositionManager
from operations.trade_prefs import TradePrefs
from risk.risk_orchestrator import RiskOrchestrator

if TYPE_CHECKING:
    from audit.audit_trail import AuditTrail
    from audit.consensus_gate import ConsensusResult
    from audit.models.snapshot import MarketSnapshot
    from database.repositories.trade_repo import TradeRepository
    from operations.alert_dispatcher import AlertDispatcher

logger = logging.getLogger(__name__)


class TradeExecutor:
    def __init__(
        self,
        *,
        order_manager: OrderManager | None = None,
        position_manager: PositionManager | None = None,
        mutex_guard: MutexGuard | None = None,
        correlation_filter: CorrelationFilter | None = None,
        risk_orchestrator: RiskOrchestrator | None = None,
        audit_trail: AuditTrail | None = None,
        trade_repository: TradeRepository | None = None,
        alert_dispatcher: AlertDispatcher | None = None,
    ) -> None:
        self.order_manager = order_manager or OrderManager()
        self.position_manager = position_manager or PositionManager()
        self.mutex = mutex_guard or MutexGuard()
        self.correlation = correlation_filter or CorrelationFilter()
        self.risk = risk_orchestrator or RiskOrchestrator()
        self.audit = audit_trail
        self.trade_repo = trade_repository
        self.alerts = alert_dispatcher

    def get_account_balance(self) -> float:
        settings = get_settings()
        if settings.execution_mode != "live":
            return settings.paper_account_balance

        if settings.mt5_enabled or settings.execution_backend == "mt5":
            try:
                from execution.mt5_bridge import get_mt5_bridge

                return get_mt5_bridge().account_balance()
            except Exception:
                logger.exception("فشل رصيد MT5 — استخدام رصيد paper")
                return settings.paper_account_balance

        if not settings.binance_api_key or not settings.binance_api_secret:
            return settings.paper_account_balance

        try:
            exchange = get_exchange()
            balance = exchange.fetch_balance()
            usdt = balance.get("USDT") or balance.get("total", {}).get("USDT")
            if isinstance(usdt, dict):
                return float(usdt.get("free", settings.paper_account_balance))
            return float(usdt or settings.paper_account_balance)
        except Exception:
            logger.exception("فشل جلب الرصيد — استخدام رصيد paper")
            return settings.paper_account_balance

    def _reject(
        self,
        symbol: str,
        reason: str,
        *,
        snapshot: MarketSnapshot | None = None,
        shadow_consensus: bool = False,
    ) -> ExecutionResult:
        if self.audit is not None and snapshot is not None:
            self.audit.log_reject(snapshot, reason, shadow_consensus=shadow_consensus)
        return ExecutionResult(
            executed=False,
            symbol=symbol,
            message="مرفوض",
            rejected=True,
            reason=reason,
        )

    def try_open(
        self,
        result: AnalysisResult,
        *,
        snapshot: MarketSnapshot | None = None,
        consensus: ConsensusResult | None = None,
        prefs: TradePrefs | None = None,
    ) -> ExecutionResult:
        symbol = result.symbol

        if snapshot is None or consensus is None:
            if self.audit is not None:
                snapshot, consensus = self.audit.evaluate_entry(result)

        if consensus is not None and not consensus.approved:
            return self._reject(
                symbol,
                f"Shadow: {consensus.reason}",
                snapshot=snapshot,
                shadow_consensus=False,
            )

        if result.halted:
            return self._reject(symbol, "market_halt", snapshot=snapshot)

        if not meets_signal_minimum(result.score) or not result.passed:
            return self._reject(symbol, f"score={result.score}", snapshot=snapshot)

        if result.signal != "BUY SIGNAL":
            return self._reject(symbol, result.signal, snapshot=snapshot)

        settings = get_settings()

        if self.position_manager.has(symbol):
            return self._reject(symbol, "existing_position", snapshot=snapshot)

        if self.position_manager.count() >= settings.max_concurrent_positions:
            return self._reject(symbol, "max_positions", snapshot=snapshot)

        allowed, corr_reason = self.correlation.can_open(
            symbol, self.position_manager.open_symbols()
        )
        if not allowed:
            return self._reject(symbol, corr_reason, snapshot=snapshot)

        if not self.mutex.try_acquire(symbol):
            return self._reject(symbol, "mutex_locked", snapshot=snapshot)

        try:
            return self._execute_entry(result, snapshot=snapshot, prefs=prefs)
        finally:
            self.mutex.release(symbol)

    def _persist_open_trade(self, position: Position) -> None:
        if self.trade_repo is None:
            return
        from database.repositories.trade_repo import TradeRow

        self.trade_repo.save_trade(
            TradeRow(
                id=position.id,
                symbol=position.symbol,
                side=position.side.value,
                entry_price=position.entry_price,
                amount=position.amount,
                status="open",
                opened_at=position.opened_at.isoformat(),
                stop_loss=position.stop_loss,
                take_profit=position.take_profit,
                is_paper=position.is_paper,
                breakeven_applied=position.breakeven_applied,
                partial_exit_done=position.partial_exit_done,
            )
        )

    def restore_open_positions(self) -> int:
        """إعادة تحميل المراكز المفتوحة من قاعدة البيانات بعد الإقلاع."""
        if self.trade_repo is None:
            return 0
        restored = 0
        for row in self.trade_repo.list_open_trades():
            if self.position_manager.has(row.symbol):
                continue
            sl = row.stop_loss if row.stop_loss is not None else row.entry_price * 0.97
            tp = row.take_profit if row.take_profit is not None else row.entry_price * 1.06
            try:
                opened_at = datetime.fromisoformat(row.opened_at)
            except ValueError:
                opened_at = datetime.now(timezone.utc)
            try:
                side = OrderSide(row.side)
            except ValueError:
                side = OrderSide.BUY
            position = Position(
                symbol=row.symbol,
                side=side,
                entry_price=row.entry_price,
                amount=row.amount,
                stop_loss=sl,
                take_profit=tp,
                id=row.id,
                opened_at=opened_at,
                breakeven_applied=row.breakeven_applied,
                partial_exit_done=row.partial_exit_done,
                is_paper=row.is_paper,
            )
            self.position_manager.add(position)
            restored += 1
        if restored:
            logger.info("Restored %s open position(s) from database", restored)
        return restored

    def _persist_close_trade(self, position_id: str, exit_price: float, pnl: float) -> None:
        if self.trade_repo is None:
            return
        self.trade_repo.close_trade(position_id, exit_price=exit_price, pnl=pnl)

    def _notify_close(self, symbol: str, pnl: float, reason: str) -> None:
        if self.alerts is not None:
            self.alerts.trade_closed(symbol, pnl, reason)

    def _execute_entry(
        self,
        result: AnalysisResult,
        *,
        snapshot: MarketSnapshot | None,
        prefs: TradePrefs | None = None,
    ) -> ExecutionResult:
        settings = get_settings()
        balance = self.get_account_balance()

        risk_approval = self.risk.evaluate_entry(
            result.symbol,
            result.price,
            balance,
            signal_score=result.score,
        )
        if not risk_approval.approved:
            return self._reject(
                result.symbol,
                risk_approval.reason,
                snapshot=snapshot,
            )

        if prefs is not None:
            from risk.lot_calculator import LotCalculator

            lot_calc = LotCalculator(balance)
            amount, stop_loss, take_profit = lot_calc.calculate(
                result.price,
                sl_pct=prefs.sl_pct,
                rr_ratio=prefs.rr_ratio,
                risk_pct=prefs.risk_pct,
            )
            if amount <= 0 or not lot_calc.is_rr_acceptable(result.price, stop_loss, take_profit):
                return self._reject(result.symbol, "إعدادات اللوت غير صالحة", snapshot=snapshot)
        else:
            amount = risk_approval.amount
            stop_loss = risk_approval.stop_loss
            take_profit = risk_approval.take_profit

        if amount <= 0:
            return self._reject(result.symbol, "zero_amount", snapshot=snapshot)

        chunks = split_order(amount, result.price)
        filled_amount = 0.0
        last_fill = result.price

        try:
            for chunk in chunks:
                order = self.order_manager.create_market_order(
                    result.symbol,
                    OrderSide.BUY,
                    chunk,
                    reference_price=result.price,
                )
                filled_amount += order.amount
                last_fill = order.fill_price or result.price
        except ExecutionError as exc:
            return self._reject(result.symbol, str(exc), snapshot=snapshot)

        position = Position(
            symbol=result.symbol,
            side=OrderSide.BUY,
            entry_price=last_fill,
            amount=round(filled_amount, 8),
            stop_loss=stop_loss,
            take_profit=take_profit,
            is_paper=settings.execution_mode != "live",
        )
        self.position_manager.add(position)
        self._persist_open_trade(position)

        if self.audit is not None and snapshot is not None:
            self.audit.log_entry(
                snapshot,
                position_id=position.id,
                reason="Shadow consensus + risk approved",
            )

        mode_label = "PAPER" if settings.execution_mode != "live" else "LIVE"
        return ExecutionResult(
            executed=True,
            symbol=result.symbol,
            position_id=position.id,
            message=(
                f"[{mode_label}] شراء {position.amount} @ {position.entry_price:.2f} "
                f"SL={position.stop_loss:.2f} TP={position.take_profit:.2f}"
            ),
        )

    def close_position(self, symbol: str, price: float, reason: str = "Manual Close") -> bool:
        position = self.position_manager.get(symbol)
        if position is None:
            return False
        self._close_position(position, price, reason)
        return True

    def close_position_partial(
        self,
        symbol: str,
        price: float,
        fraction: float,
        *,
        reason: str = "Partial Close",
    ) -> bool:
        position = self.position_manager.get(symbol)
        if position is None or fraction <= 0:
            return False

        amount = round(position.amount * fraction, 8)
        if amount <= 0:
            return False

        if position.side == OrderSide.BUY:
            pnl = (price - position.entry_price) * amount
            exit_side = OrderSide.SELL
        else:
            pnl = (position.entry_price - price) * amount
            exit_side = OrderSide.BUY

        self.order_manager.create_market_order(
            position.symbol,
            exit_side,
            amount,
            reference_price=price,
        )
        self.position_manager.reduce_amount(symbol, amount)
        self.risk.record_closed_trade(pnl)
        self._notify_close(position.symbol, pnl, reason)
        if self.audit is not None:
            self.audit.log_exit(position.symbol, reason=reason, pnl=pnl, position_id=position.id)
        return True

    def apply_breakeven(self, symbol: str) -> bool:
        position = self.position_manager.get(symbol)
        if position is None:
            return False
        updated = self.position_manager.update_stop_loss(symbol, position.entry_price)
        if updated is not None:
            self._persist_open_trade(updated)
        return True

    def adjust_position_sl(self, symbol: str, sl_pct: float) -> bool:
        position = self.position_manager.get(symbol)
        if position is None:
            return False
        from execution.sl_tp_calculator import calculate_sl_tp

        stop_loss, _ = calculate_sl_tp(position.entry_price, sl_pct=sl_pct)
        updated = self.position_manager.update_stop_loss(symbol, stop_loss)
        if updated is not None:
            self._persist_open_trade(updated)
        return True

    def adjust_position_tp(self, symbol: str, rr_ratio: float) -> bool:
        position = self.position_manager.get(symbol)
        if position is None:
            return False
        from execution.sl_tp_calculator import calculate_sl_tp

        sl_pct = abs(position.entry_price - position.stop_loss) / position.entry_price
        _, take_profit = calculate_sl_tp(
            position.entry_price,
            sl_pct=sl_pct,
            rr_ratio=rr_ratio,
        )
        updated = self.position_manager.update_take_profit(symbol, take_profit)
        if updated is not None:
            self._persist_open_trade(updated)
        return True

    def manage_positions(self, prices: dict[str, float]) -> list[BreakevenAction]:
        actions: list[BreakevenAction] = []

        for position in list(self.position_manager.all()):
            current = prices.get(position.symbol)
            if current is None or current <= 0:
                continue

            if position.side == OrderSide.BUY and current <= position.stop_loss:
                self._close_position(position, current, "Stop Loss")
                continue

            if position.side == OrderSide.BUY and current >= position.take_profit:
                self._close_position(position, current, "Take Profit")
                continue

            action = evaluate_breakeven(position, current)
            if not action.move_sl_to_breakeven and action.partial_exit_amount <= 0:
                continue

            if action.move_sl_to_breakeven and action.new_stop_loss is not None:
                updated = self.position_manager.update_stop_loss(position.symbol, action.new_stop_loss)
                if updated is not None:
                    self._persist_open_trade(updated)

            if action.partial_exit_amount > 0 and not position.partial_exit_done:
                self.order_manager.create_market_order(
                    position.symbol,
                    OrderSide.SELL,
                    action.partial_exit_amount,
                    reference_price=current,
                )
                updated = self.position_manager.reduce_amount(
                    position.symbol, action.partial_exit_amount
                )
                if updated is not None:
                    updated.partial_exit_done = True
                    self._persist_open_trade(updated)

            actions.append(action)

        return actions

    def _close_position(self, position: Position, price: float, reason: str) -> None:
        pnl = 0.0
        if position.side == OrderSide.BUY:
            pnl = (price - position.entry_price) * position.amount

        self.order_manager.create_market_order(
            position.symbol,
            OrderSide.SELL,
            position.amount,
            reference_price=price,
        )
        self.position_manager.remove(position.symbol)
        self.risk.record_closed_trade(pnl)
        self._persist_close_trade(position.id, price, pnl)
        self._notify_close(position.symbol, pnl, reason)

        if self.audit is not None:
            self.audit.log_exit(
                position.symbol,
                reason=reason,
                pnl=pnl,
                position_id=position.id,
            )
        logger.info("إغلاق %s — %s @ %.2f (PnL: %.2f)", position.symbol, reason, price, pnl)

    def emergency_close_all(self, prices: dict[str, float] | None = None) -> list[str]:
        results = emergency_flat(
            self.order_manager,
            self.position_manager,
            prices=prices,
        )
        price_map = prices or {}
        for item in results:
            self.risk.record_closed_trade(item.pnl)
            exit_price = price_map.get(item.symbol, 0.0)
            self._persist_close_trade(item.position_id, exit_price, item.pnl)
            self._notify_close(item.symbol, item.pnl, "Emergency Flat")
            if self.audit is not None:
                self.audit.log_exit(
                    item.symbol,
                    reason="Emergency Flat",
                    pnl=item.pnl,
                    position_id=item.position_id,
                )
        return [item.symbol for item in results]
