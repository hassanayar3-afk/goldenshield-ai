@echo off
cd /d %~dp0
py -m pip install -r requirements.txt MetaTrader5
if not exist storage\db\backups mkdir storage\db\backups
if not exist storage\logs mkdir storage\logs
echo Keep MetaTrader5 open and logged in.
py -u main.py
pause
