"""تعبئة المشروع وإرساله عبر تيليجرام كبديل لـ SSH."""

from __future__ import annotations

import os
import zipfile
from pathlib import Path

import requests
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
EXCLUDE = {".venv", "__pycache__", ".git", ".pytest_cache", ".mypy_cache", ".cursor", "htmlcov"}
EXCLUDE_SUF = {".pyc", ".pyo", ".log"}


def main() -> int:
    load_dotenv(ROOT / ".env", override=True)
    token = os.getenv("TELEGRAM_TOKEN")
    chat = os.getenv("TELEGRAM_CHAT_ID")
    if not token or not chat:
        print("Telegram config missing")
        return 1

    local: dict[str, str] = {}
    for line in (ROOT / ".env").read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        local[k.strip()] = v.strip()

    env_txt = "\n".join(
        [
            "ENV=production",
            "EXECUTION_MODE=live",
            "EXECUTION_BACKEND=mt5",
            "MT5_ENABLED=true",
            f"MT5_LOGIN={local.get('MT5_LOGIN', '345814054')}",
            f"MT5_PASSWORD={local.get('MT5_PASSWORD', '')}",
            f"MT5_SERVER={local.get('MT5_SERVER', 'XMGlobal-MT5 10')}",
            "MT5_BROKER=XM",
            "MANUAL_ENTRY_REQUIRED=false",
            f"TELEGRAM_TOKEN={local.get('TELEGRAM_TOKEN', '')}",
            f"TELEGRAM_BOT_USERNAME={local.get('TELEGRAM_BOT_USERNAME', 'GoldenShield_2026_bot')}",
            f"TELEGRAM_CHAT_ID={local.get('TELEGRAM_CHAT_ID', '')}",
            f"TELEGRAM_BACKUP_CHANNEL_ID={local.get('TELEGRAM_BACKUP_CHANNEL_ID', '-1004462420308')}",
            "TELEGRAM_SEND_CYCLE_SIGNALS=false",
            "DB_PATH=storage/db/goldenshield.db",
        ]
    ) + "\n"

    bat = (
        "@echo off\r\n"
        "cd /d %~dp0\r\n"
        "py -m pip install -r requirements.txt MetaTrader5\r\n"
        "if not exist storage\\db\\backups mkdir storage\\db\\backups\r\n"
        "if not exist storage\\logs mkdir storage\\logs\r\n"
        "echo Keep MetaTrader5 open and logged in.\r\n"
        "py -u main.py\r\n"
        "pause\r\n"
    )

    zip_path = ROOT / "storage" / "goldenshield_windows_deploy.zip"
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in ROOT.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(ROOT)
            if set(rel.parts) & EXCLUDE:
                continue
            if rel.suffix in EXCLUDE_SUF:
                continue
            if rel.name == ".env":
                continue
            if "storage" in rel.parts and rel.suffix in {".db", ".zip"}:
                continue
            zf.write(path, str(rel).replace("\\", "/"))
        zf.writestr(".env", env_txt)
        zf.writestr("START_WINDOWS.bat", bat)

    print("zip_bytes", zip_path.stat().st_size)
    caption = (
        "حزمة GoldenShield لسيرفر Windows\n"
        "1) من داخل السيرفر افتح Edge → web.telegram.org\n"
        "2) سجل دخولك وافتح محادثة البوت\n"
        "3) حمّل هذا الملف zip\n"
        "4) فكّه إلى المجلد C:\\GoldenShield\n"
        "5) ميتاتريدر مفتوح ومسجّل دخول\n"
        "6) شغّل الملف START_WINDOWS.bat"
    )
    with zip_path.open("rb") as fh:
        response = requests.post(
            f"https://api.telegram.org/bot{token}/sendDocument",
            data={"chat_id": chat, "caption": caption},
            files={"document": ("goldenshield_windows_deploy.zip", fh)},
            timeout=180,
        )
    data = response.json()
    print(response.status_code, data.get("ok"), data.get("description", "ok"))
    return 0 if data.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
