import os
import sys

import paramiko

host = os.environ.get("DEPLOY_HOST", "169.58.8.253")
password = os.environ.get("DEPLOY_PASSWORD", "")
if not password:
    print("DEPLOY_PASSWORD missing")
    sys.exit(1)

client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(
    host,
    username="root",
    password=password,
    timeout=30,
    allow_agent=False,
    look_for_keys=False,
)

cmds = [
    'docker ps --filter name=goldenshield-bot --format "{{.Names}} | {{.Status}}"',
    "systemctl is-enabled goldenshield; systemctl is-active goldenshield || true",
    "docker logs --tail 30 goldenshield-bot 2>&1",
]
for cmd in cmds:
    print("===", cmd)
    _, stdout, stderr = client.exec_command(cmd, timeout=60)
    print(stdout.read().decode("utf-8", errors="replace"))
    err = stderr.read().decode("utf-8", errors="replace")
    if err.strip():
        print(err)

client.close()
print("CHECK_DONE")
