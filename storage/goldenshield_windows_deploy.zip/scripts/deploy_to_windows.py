"""رفع GoldenShield إلى سيرفر Windows عبر SSH وتشغيل الإعداد."""

from __future__ import annotations

import io
import os
import sys
import tarfile
import time
from pathlib import Path

import paramiko

ROOT = Path(__file__).resolve().parents[1]
HOST = os.environ.get("WIN_HOST", "169.58.15.36")
USER = os.environ.get("WIN_USER", "Administrator")
PASSWORD = os.environ.get("WIN_PASSWORD", "")
REMOTE_DIR = r"C:\GoldenShield"

EXCLUDE_DIRS = {".venv", "__pycache__", ".git", ".pytest_cache", ".mypy_cache", ".cursor", "htmlcov"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".log"}


def should_skip(rel: Path) -> bool:
    if set(rel.parts) & EXCLUDE_DIRS:
        return True
    if rel.suffix in EXCLUDE_SUFFIXES:
        return True
    if rel.name == ".env":
        return True
    return False


def build_archive() -> bytes:
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for path in ROOT.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(ROOT)
            if should_skip(rel):
                continue
            tar.add(path, arcname=str(rel).replace("\\", "/"))
    return buf.getvalue()


def production_env() -> str:
    local: dict[str, str] = {}
    env_path = ROOT / ".env"
    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            local[k.strip()] = v.strip()

    values = {
        "ENV": "production",
        "EXECUTION_MODE": "live",
        "EXECUTION_BACKEND": "mt5",
        "MT5_ENABLED": "true",
        "MT5_LOGIN": local.get("MT5_LOGIN", "345814054"),
        "MT5_PASSWORD": local.get("MT5_PASSWORD", ""),
        "MT5_SERVER": local.get("MT5_SERVER", "XMGlobal-MT5 10"),
        "MT5_BROKER": "XM",
        "MANUAL_ENTRY_REQUIRED": "false",
        "TELEGRAM_TOKEN": local.get("TELEGRAM_TOKEN", ""),
        "TELEGRAM_BOT_USERNAME": local.get("TELEGRAM_BOT_USERNAME", "GoldenShield_2026_bot"),
        "TELEGRAM_CHAT_ID": local.get("TELEGRAM_CHAT_ID", ""),
        "TELEGRAM_BACKUP_CHANNEL_ID": local.get("TELEGRAM_BACKUP_CHANNEL_ID", "-1004462420308"),
        "TELEGRAM_SEND_CYCLE_SIGNALS": "false",
        "DB_PATH": r"storage\db\goldenshield.db",
    }
    return "\n".join(f"{k}={v}" for k, v in values.items()) + "\n"


def run(ssh: paramiko.SSHClient, cmd: str, timeout: int = 600) -> tuple[int, str]:
    print("$", cmd)
    stdin, stdout, stderr = ssh.exec_command(cmd, timeout=timeout)
    out = stdout.read().decode("utf-8", errors="replace")
    err = stderr.read().decode("utf-8", errors="replace")
    code = stdout.channel.recv_exit_status()
    if out.strip():
        print(out[-3000:])
    if err.strip():
        print(err[-1500:])
    return code, out + err


def main() -> int:
    if not PASSWORD:
        print("Set WIN_PASSWORD")
        return 1

    archive = build_archive()
    print(f"archive={len(archive)/1024:.1f} KB")

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(HOST, username=USER, password=PASSWORD, timeout=45, allow_agent=False, look_for_keys=False)

    run(ssh, r'powershell -NoProfile -Command "New-Item -ItemType Directory -Force -Path C:\GoldenShield, C:\GoldenShield\storage\db\backups, C:\GoldenShield\storage\logs | Out-Null"')

    sftp = ssh.open_sftp()
    remote_tar = "/tmp/gs_win.tgz"
    # Windows OpenSSH often maps / to C:\ or user home — use explicit path
    remote_tar_win = r"C:\GoldenShield\_deploy.tgz"
    with sftp.file(remote_tar_win.replace("\\", "/"), "wb") as rf:
        rf.write(archive)
    with sftp.file((REMOTE_DIR + r"\.env").replace("\\", "/"), "w") as ef:
        ef.write(production_env())
    sftp.close()

    # extract with tar if available, else PowerShell 5+ tar
    code, _ = run(
        ssh,
        r'powershell -NoProfile -Command "Set-Location C:\GoldenShield; tar -xzf _deploy.tgz; Remove-Item _deploy.tgz -Force -ErrorAction SilentlyContinue"',
        timeout=300,
    )
    if code != 0:
        print("extract failed", code)
        ssh.close()
        return 1

    run(ssh, r'powershell -NoProfile -Command "Set-Location C:\GoldenShield; py -m pip install -r requirements.txt MetaTrader5"', timeout=900)

    # create scheduled task to keep bot running
    create_task = r'''powershell -NoProfile -Command "$action = New-ScheduledTaskAction -Execute 'py' -Argument '-u main.py' -WorkingDirectory 'C:\GoldenShield'; $trigger = New-ScheduledTaskTrigger -AtStartup; Register-ScheduledTask -TaskName 'GoldenShieldBot' -Action $action -Trigger $trigger -User Administrator -Password ''' + PASSWORD.replace("'", "''") + r''' -RunLevel Highest -Force; Start-ScheduledTask -TaskName GoldenShieldBot"'''
    run(ssh, create_task, timeout=120)

    time.sleep(5)
    run(ssh, r'powershell -NoProfile -Command "Get-ScheduledTask -TaskName GoldenShieldBot | Select-Object TaskName,State"')
    ssh.close()
    print("WINDOWS_DEPLOY_DONE")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
