"""فحص ما قبل التشغيل — يمنع البدء عند الفشل."""

from __future__ import annotations

from dataclasses import dataclass, field

from config.settings import get_settings
from data.connection_monitor import ConnectionMonitor
from operations.api_watchdog import ApiWatchdog
from operations.telegram_utils import validate_chat_id


@dataclass(frozen=True)
class PreFlightCheck:
    name: str
    passed: bool
    detail: str


@dataclass(frozen=True)
class PreFlightResult:
    ok: bool
    checks: list[PreFlightCheck] = field(default_factory=list)


def run_pre_flight(
    *,
    connection_monitor: ConnectionMonitor | None = None,
    skip_binance_ping: bool = False,
) -> PreFlightResult:
    settings = get_settings()
    checks: list[PreFlightCheck] = []

    monitor = None if skip_binance_ping else connection_monitor
    watchdog = ApiWatchdog().run(monitor)

    for key, passed in watchdog.checks.items():
        detail = "OK" if passed else "فشل"
        checks.append(PreFlightCheck(name=key, passed=passed, detail=detail))

    for failure in watchdog.failures:
        checks.append(PreFlightCheck(name="failure", passed=False, detail=failure))

    if settings.min_account_balance <= 0:
        checks.append(
            PreFlightCheck(
                name="min_account_balance",
                passed=False,
                detail="الحد الأدنى للرصيد غير صالح",
            )
        )

    telegram_ready = bool(settings.telegram_token and settings.telegram_chat_id)
    chat_ok, chat_detail = validate_chat_id(
        settings.telegram_token,
        settings.telegram_chat_id,
    )
    checks.append(
        PreFlightCheck(
            name="telegram_optional",
            passed=True,
            detail="مُهيّأ" if telegram_ready and chat_ok else "اختياري — غير مُعدّ (تنبيهات محلية فقط)",
        )
    )
    if settings.telegram_chat_id:
        checks.append(
            PreFlightCheck(
                name="telegram_chat_id",
                passed=chat_ok,
                detail=chat_detail,
            )
        )

    ok = all(
        c.passed
        for c in checks
        if c.name not in {"telegram_optional"}
    )
    return PreFlightResult(ok=ok, checks=checks)
