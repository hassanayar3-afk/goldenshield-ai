"""توزيع التنبيهات — Telegram + سجلات."""

from __future__ import annotations

from enum import Enum

from operations.error_logger import log_error, log_operation
from operations.message_templates import (
    format_alert_message,
    format_emergency_message,
    format_trade_close_message,
    format_trade_open_message,
)
from operations.telegram_bot import TelegramBot


class AlertLevel(str, Enum):
    INFO = "info"
    WARNING = "warning"
    EMERGENCY = "emergency"


class AlertDispatcher:
    def __init__(self, telegram: TelegramBot | None = None) -> None:
        self.telegram = telegram or TelegramBot()

    def _log_plain(self, level: AlertLevel, title: str, detail: str = "") -> None:
        text = f"[{level.value.upper()}] {title}"
        if detail:
            text += f"\n{detail}"
        log_operation(text)
        if level in {AlertLevel.WARNING, AlertLevel.EMERGENCY}:
            log_error(f"{title}: {detail}" if detail else title)

    def dispatch(self, level: AlertLevel, title: str, detail: str = "") -> bool:
        self._log_plain(level, title, detail)
        return self.telegram.send_message(format_alert_message(level.value, title, detail))

    def send_formatted(self, text: str, *, plain_log: str) -> bool:
        log_operation(plain_log)
        return self.telegram.send_message(text)

    def emergency(self, title: str, detail: str = "") -> bool:
        self._log_plain(AlertLevel.EMERGENCY, title, detail)
        return self.telegram.send_message(format_emergency_message(title, detail))

    def trade_opened(self, symbol: str, detail: str) -> bool:
        plain = f"[INFO] صفقة جديدة {symbol}\n{detail}"
        log_operation(plain)
        return self.telegram.send_message(format_trade_open_message(symbol, detail))

    def trade_closed(self, symbol: str, pnl: float, reason: str) -> bool:
        sign = "+" if pnl >= 0 else ""
        plain = f"[INFO] إغلاق {symbol}\nPnL: {sign}{pnl:.2f} USDT | {reason}"
        log_operation(plain)
        return self.telegram.send_message(format_trade_close_message(symbol, pnl, reason))

    def kill_switch_activated(self, reason: str) -> bool:
        return self.emergency("Kill Switch", reason)
