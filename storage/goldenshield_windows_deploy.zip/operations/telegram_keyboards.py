"""أزرار لوحة التحكم — حسب دستور GoldenShield (بسيطة ومختصرة)."""

from __future__ import annotations

from config.settings import get_settings


def _encode_symbol(symbol: str) -> str:
    return symbol.replace("/", "")


def decode_symbol(token: str) -> str:
    settings = get_settings()
    for pair in settings.trading_pairs:
        if _encode_symbol(pair) == token:
            return pair
    if len(token) > 4 and token.endswith("USDT"):
        return f"{token[:-4]}/USDT"
    return token


def encode_symbol(symbol: str) -> str:
    return _encode_symbol(symbol)


def main_menu_keyboard(*, paused: bool) -> dict:
    toggle = (
        {"text": "▶️ تشغيل", "callback_data": "act:resume"}
        if paused
        else {"text": "⏸️ إيقاف", "callback_data": "act:pause"}
    )
    return {
        "inline_keyboard": [
            [
                {"text": "📡 الإشارات", "callback_data": "view:market"},
                {"text": "📂 مراكزي", "callback_data": "view:positions"},
            ],
            [
                {"text": "📋 التقرير", "callback_data": "view:report"},
                toggle,
            ],
            [{"text": "🚨 طوارئ — إغلاق الكل", "callback_data": "act:panic"}],
        ]
    }


def market_keyboard(symbols: list[str], *, entries: list[dict] | None = None) -> dict:
    """أزرار العملات مرتبة من الأقوى للأضعف مع أيقونة القوة."""
    from core.constants import SIGNAL_MIN_PERCENT, score_to_percent

    score_map = {e["symbol"]: int(e.get("score", 0)) for e in (entries or [])}
    ordered = sorted(symbols, key=lambda s: score_map.get(s, 0), reverse=True)
    rows: list[list[dict]] = []
    row: list[dict] = []
    for symbol in ordered:
        score = score_map.get(symbol, 0)
        percent = score_to_percent(score)
        if percent >= SIGNAL_MIN_PERCENT:
            icon = "🟢"
        elif percent >= 70:
            icon = "🟡"
        elif percent >= 50:
            icon = "🟠"
        else:
            icon = "🔴"
        row.append(
            {
                "text": f"{icon} {symbol.split('/')[0]} {percent}",
                "callback_data": f"sym:{encode_symbol(symbol)}",
            }
        )
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([{"text": "◀️ الرئيسية", "callback_data": "view:main"}])
    return {"inline_keyboard": rows}


def trade_entry_keyboard(symbol: str, *, can_enter: bool) -> dict:
    token = encode_symbol(symbol)
    rows: list[list[dict]] = []
    if can_enter:
        rows.append([{"text": "✅ دخول الصفقة الآن", "callback_data": f"enter:{token}"}])
    else:
        rows.append([{"text": "⏳ دخول الصفقة (غير جاهزة)", "callback_data": f"sym:{token}"}])
    rows.append(
        [
            {"text": "🔄 تحديث", "callback_data": f"sym:{token}"},
            {"text": "◀️ الإشارات", "callback_data": "view:market"},
        ]
    )
    return {"inline_keyboard": rows}


def position_trade_keyboard(symbol: str) -> dict:
    token = encode_symbol(symbol)
    return {
        "inline_keyboard": [
            [
                {"text": "❌ إغلاق الصفقة", "callback_data": f"close:{token}"},
                {"text": "🔄 تحديث", "callback_data": f"pos:{token}"},
            ],
            [
                {"text": "◀️ مراكزي", "callback_data": "view:positions"},
                {"text": "🏠 الرئيسية", "callback_data": "view:main"},
            ],
        ]
    }


def back_to_main_keyboard() -> dict:
    return {"inline_keyboard": [[{"text": "◀️ الرئيسية", "callback_data": "view:main"}]]}
