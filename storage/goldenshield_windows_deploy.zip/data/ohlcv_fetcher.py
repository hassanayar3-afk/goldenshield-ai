from __future__ import annotations

from core.constants import DEFAULT_OHLCV_LIMIT, TIMEFRAMES
from data.cache_manager import get_cache_manager
from data.connection_utils import fetch_with_retry
from data.exchange_client import get_exchange
from data.models.candle import Candle

SUPPORTED_TIMEFRAMES: tuple[str, ...] = (*TIMEFRAMES, "1d")


class OHLCVFetcher:
    """جلب شموع OHLCV من Binance مع Cache."""

    def __init__(self, cache_ttl_seconds: int | None = None) -> None:
        self._cache = get_cache_manager()
        self._cache_ttl = cache_ttl_seconds

    def _cache_key(self, symbol: str, timeframe: str, limit: int) -> str:
        return f"ohlcv:{symbol}:{timeframe}:{limit}"

    def fetch(
        self,
        symbol: str,
        timeframe: str,
        *,
        limit: int = DEFAULT_OHLCV_LIMIT,
        use_cache: bool = True,
    ) -> list[Candle]:
        if timeframe not in SUPPORTED_TIMEFRAMES:
            raise ValueError(
                f"إطار زمني غير مدعوم: {timeframe}. المسموح: {SUPPORTED_TIMEFRAMES}"
            )

        cache_key = self._cache_key(symbol, timeframe, limit)
        if use_cache:
            cached = self._cache.get(cache_key)
            if cached is not None:
                return cached

        def _fetch() -> list[Candle]:
            exchange = get_exchange()
            raw_rows = exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
            return [Candle.from_ohlcv_row(row) for row in raw_rows]

        candles = fetch_with_retry(
            _fetch,
            operation_name=f"fetch_ohlcv({symbol},{timeframe})",
        )

        if use_cache:
            self._cache.set(cache_key, candles, ttl_seconds=self._cache_ttl)

        return candles

    def fetch_multi(
        self,
        symbol: str,
        timeframes: tuple[str, ...] = TIMEFRAMES,
        *,
        limit: int = DEFAULT_OHLCV_LIMIT,
        use_cache: bool = True,
    ) -> dict[str, list[Candle]]:
        return {
            timeframe: self.fetch(symbol, timeframe, limit=limit, use_cache=use_cache)
            for timeframe in timeframes
        }
