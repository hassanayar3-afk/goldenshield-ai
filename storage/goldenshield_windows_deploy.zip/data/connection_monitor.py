from __future__ import annotations

import time

from core.constants import HEARTBEAT_TIMEOUT_SECONDS
from data.connection_utils import ping_exchange


class ConnectionMonitor:
    """مراقبة Heartbeat — كشف انقطاع الاتصال."""

    def __init__(self, timeout_seconds: int = HEARTBEAT_TIMEOUT_SECONDS) -> None:
        self._timeout_seconds = timeout_seconds
        self._last_success_monotonic: float | None = None
        self._last_error: str | None = None

    @property
    def timeout_seconds(self) -> int:
        return self._timeout_seconds

    @property
    def last_error(self) -> str | None:
        return self._last_error

    def record_success(self) -> None:
        self._last_success_monotonic = time.monotonic()
        self._last_error = None

    def record_failure(self, error: str) -> None:
        self._last_error = error

    def seconds_since_last_success(self) -> float | None:
        if self._last_success_monotonic is None:
            return None
        return time.monotonic() - self._last_success_monotonic

    def is_connected(self) -> bool:
        elapsed = self.seconds_since_last_success()
        if elapsed is None:
            return True
        return elapsed <= self._timeout_seconds

    def is_disconnected(self) -> bool:
        return not self.is_connected()

    def heartbeat(self) -> bool:
        """فحص اتصال Binance — يُرجع True عند النجاح."""
        try:
            ping_exchange()
            self.record_success()
            return True
        except Exception as exc:
            self.record_failure(str(exc))
            return False
