from __future__ import annotations

from data.cache_manager import get_cache_manager
from data.connection_utils import fetch_with_retry
from data.exchange_client import get_exchange
from data.models.ticker import Ticker


class TickerFetcher:
    """جلب السعر اللحظي والسبريد."""

    def __init__(self, cache_ttl_seconds: int = 5) -> None:
        self._cache = get_cache_manager()
        self._cache_ttl = cache_ttl_seconds

    def fetch(self, symbol: str, *, use_cache: bool = True) -> Ticker:
        cache_key = f"ticker:{symbol}"

        if use_cache:
            cached = self._cache.get(cache_key)
            if cached is not None:
                return cached

        def _fetch() -> Ticker:
            exchange = get_exchange()
            raw = exchange.fetch_ticker(symbol)
            return Ticker.from_ccxt(symbol, raw)

        ticker = fetch_with_retry(
            _fetch,
            operation_name=f"fetch_ticker({symbol})",
        )

        if use_cache:
            self._cache.set(cache_key, ticker, ttl_seconds=self._cache_ttl)

        return ticker
