from __future__ import annotations

import ccxt

from config.settings import get_settings

_exchange: ccxt.binance | None = None


def get_exchange() -> ccxt.binance:
    """عميل Binance موحّد (Singleton) مع Rate Limiting."""
    global _exchange

    if _exchange is not None:
        return _exchange

    settings = get_settings()
    options: dict = {
        "enableRateLimit": True,
        "timeout": 30000,
    }

    if settings.binance_api_key and settings.binance_api_secret:
        options["apiKey"] = settings.binance_api_key
        options["secret"] = settings.binance_api_secret

    _exchange = ccxt.binance(options)
    return _exchange


def reset_exchange() -> None:
    """إعادة ضبط العميل — للاختبارات."""
    global _exchange
    _exchange = None
