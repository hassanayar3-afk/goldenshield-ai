"""منسق المخاطر — بوابة إلزامية قبل كل صفقة."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from config.settings import get_settings
from core.constants import SIGNAL_MIN_PERCENT, meets_signal_minimum
from data.connection_monitor import ConnectionMonitor
from risk.compound_growth import effective_risk_pct
from risk.daily_limits import check_daily_limits
from risk.gradual_scaling import scaling_multiplier
from risk.heartbeat_guard import check_heartbeat_guard
from risk.inspection_mode import check_inspection_mode
from risk.kill_switch import check_kill_switch
from risk.loss_streak_guard import check_loss_streak
from risk.lot_calculator import LotCalculator
from risk.monte_carlo import run_monte_carlo
from risk.state import RiskState


@dataclass(frozen=True)
class RiskApproval:
    approved: bool
    reason: str
    amount: float = 0.0
    stop_loss: float = 0.0
    take_profit: float = 0.0


class RiskOrchestrator:
    def __init__(
        self,
        *,
        state: RiskState | None = None,
        connection_monitor: ConnectionMonitor | None = None,
        persist_callback=None,
    ) -> None:
        self.connection_monitor = connection_monitor
        self._state = state
        self._session_day = date.today() if state is not None else None
        self._persist_callback = persist_callback

    @property
    def state(self) -> RiskState | None:
        return self._state

    @property
    def session_day(self) -> date | None:
        return self._session_day

    def set_persist_callback(self, callback) -> None:
        self._persist_callback = callback

    def restore_state(self, state: RiskState, session_day: date | None = None) -> None:
        self._state = state
        self._session_day = session_day or date.today()

    def _persist(self) -> None:
        if self._persist_callback is not None and self._state is not None:
            self._persist_callback(self._state, self._session_day)

    def initialize(self, balance: float) -> None:
        self._state = RiskState(
            session_start_balance=balance,
            current_balance=balance,
        )
        self._session_day = date.today()
        self._persist()

    def ensure_state(self, balance: float) -> RiskState:
        today = date.today()
        if self._state is None:
            self.initialize(balance)
        elif self._session_day != today:
            self._state.reset_daily(self._state.current_balance)
            self._session_day = today
            self._persist()

        assert self._state is not None
        return self._state

    def evaluate_entry(
        self,
        symbol: str,
        entry_price: float,
        balance: float,
        *,
        signal_score: int,
    ) -> RiskApproval:
        state = self.ensure_state(balance)
        settings = get_settings()

        if balance < settings.min_account_balance:
            return RiskApproval(
                False,
                f"الرصيد {balance:.2f} أقل من الحد الأدنى {settings.min_account_balance}",
            )

        if self.connection_monitor is not None:
            heartbeat = check_heartbeat_guard(self.connection_monitor)
            if not heartbeat.safe:
                return RiskApproval(False, heartbeat.reason)

        if state.kill_switch_active:
            return RiskApproval(False, "Kill Switch مفعّل — تداول موقوف")

        kill = check_kill_switch(state.daily_pnl_pct)
        if kill.triggered:
            state.kill_switch_active = True
            self._persist()
            return RiskApproval(False, kill.reason)

        streak = check_loss_streak(state.consecutive_losses, state.cooldown_until)
        if streak.in_cooldown:
            if streak.cooldown_until and state.cooldown_until is None:
                state.cooldown_until = streak.cooldown_until
                self._persist()
            return RiskApproval(False, streak.reason)

        limits = check_daily_limits(state.daily_trades)
        if not limits.allowed:
            return RiskApproval(False, limits.reason)

        inspection = check_inspection_mode()
        if inspection.active and not meets_signal_minimum(signal_score):
            return RiskApproval(
                False,
                f"تفتيش: الدرجة أقل من {SIGNAL_MIN_PERCENT}/100",
            )

        mc_seed = hash(f"{symbol}:{date.today().isoformat()}") % 10000
        mc = run_monte_carlo(
            win_probability=min(0.55, 0.38 + signal_score * 0.01),
            seed=mc_seed,
        )
        if not mc.passed:
            return RiskApproval(False, mc.reason)

        scale = scaling_multiplier(state.session_start_balance, state.current_balance)
        lot_calc = LotCalculator(state.current_balance)
        amount, stop_loss, take_profit = lot_calc.calculate(entry_price)
        amount = round(amount * scale, 8)

        if amount <= 0:
            return RiskApproval(False, "حجم العقد صفر بعد حساب المخاطر")

        if not lot_calc.is_rr_acceptable(entry_price, stop_loss, take_profit):
            return RiskApproval(False, "نسبة المخاطرة/العائد غير مقبولة")

        risk_note = (
            f"مخاطرة {effective_risk_pct():.1f}% | "
            f"MC {mc.win_rate:.0%} | scale {scale:.1f}x"
        )
        if inspection.active:
            risk_note = f"{inspection.reason} | {risk_note}"

        return RiskApproval(
            approved=True,
            reason=risk_note,
            amount=amount,
            stop_loss=stop_loss,
            take_profit=take_profit,
        )

    def record_closed_trade(self, pnl: float) -> None:
        if self._state is None:
            return
        self._state.record_trade(pnl)

        streak = check_loss_streak(
            self._state.consecutive_losses,
            self._state.cooldown_until,
        )
        if streak.in_cooldown and streak.cooldown_until:
            self._state.cooldown_until = streak.cooldown_until

        kill = check_kill_switch(self._state.daily_pnl_pct)
        if kill.triggered:
            self._state.kill_switch_active = True
        self._persist()
