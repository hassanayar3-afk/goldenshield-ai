"""نمو تراكمي — مخاطرة ثابتة 1%."""

from __future__ import annotations

from config.settings import get_settings


def risk_amount(balance: float, risk_pct: float | None = None) -> float:
    settings = get_settings()
    pct = risk_pct if risk_pct is not None else settings.risk_per_trade_pct
    return balance * (pct / 100)


def effective_risk_pct(risk_pct: float | None = None) -> float:
    settings = get_settings()
    return risk_pct if risk_pct is not None else settings.risk_per_trade_pct
