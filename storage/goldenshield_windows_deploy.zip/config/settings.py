from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv

from core.exceptions import ConfigurationError

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_DIR = Path(__file__).resolve().parent
VALID_ENVS = frozenset({"dev", "staging", "production"})
ENV_ALIASES = {"prod": "production"}


def _load_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise ConfigurationError(f"ملف الإعدادات غير موجود: {path}")
    with path.open(encoding="utf-8") as handle:
        data = yaml.safe_load(handle)
    return data if isinstance(data, dict) else {}


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = base.copy()
    for key, value in override.items():
        if (
            key in merged
            and isinstance(merged[key], dict)
            and isinstance(value, dict)
        ):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


@dataclass(frozen=True)
class Settings:
    env: str
    trading_pairs: list[str]
    risk_per_trade_pct: float
    kill_switch_daily_pct: float
    gradual_growth_threshold_pct: float
    max_daily_trades: int
    loss_streak_limit: int
    cooldown_hours: int
    loop_interval_seconds: int
    log_level: str
    db_path: str
    binance_api_key: str | None
    binance_api_secret: str | None
    telegram_token: str | None
    telegram_chat_id: str | None
    telegram_bot_username: str | None
    telegram_backup_channel_id: str | None
    telegram_send_cycle_signals: bool
    manual_entry_required: bool
    news_filter_enabled: bool
    news_blackout_minutes: int
    vix_threshold: float
    bonds_yield_spike_pct: float
    fear_greed_extreme_low: int
    fear_greed_extreme_high: int
    whale_wall_multiplier: float
    institutional_min_levels: int
    sentiment_anomaly_threshold: float
    execution_mode: str
    paper_account_balance: float
    default_sl_pct: float
    default_rr_ratio: float
    dark_pool_max_chunk_usdt: float
    max_concurrent_positions: int
    partial_exit_pct: float
    breakeven_enabled: bool
    correlation_groups: tuple[tuple[str, ...], ...]
    min_account_balance: float
    monte_carlo_simulations: int
    monte_carlo_min_win_rate: float
    mt5_enabled: bool
    mt5_login: str | None
    mt5_password: str | None
    mt5_server: str | None
    mt5_broker: str | None
    execution_backend: str


_settings: Settings | None = None


def load_settings(env: str | None = None, *, reload: bool = False) -> Settings:
    global _settings

    if _settings is not None and not reload:
        return _settings

    load_dotenv(BASE_DIR / ".env")

    env_name = (env or os.getenv("ENV", "dev")).strip().lower()
    env_name = ENV_ALIASES.get(env_name, env_name)
    if env_name not in VALID_ENVS:
        raise ConfigurationError(
            f"بيئة غير صالحة: {env_name}. المسموح: {', '.join(sorted(VALID_ENVS))}"
        )

    trading_config = _load_yaml(CONFIG_DIR / "trading_pairs.yaml")
    risk_config = _load_yaml(CONFIG_DIR / "risk_params.yaml")
    hybrid_config = _load_yaml(CONFIG_DIR / "hybrid_params.yaml")
    execution_config = _load_yaml(CONFIG_DIR / "execution_params.yaml")
    env_config = _load_yaml(CONFIG_DIR / "environments" / f"{env_name}.yaml")

    merged = _deep_merge(
        {
            "trading": trading_config,
            "risk": risk_config,
            "hybrid": hybrid_config,
            "execution": execution_config,
            "app": {"loop_interval_seconds": 60, "log_level": "INFO"},
            "database": {"path": "storage/db/goldenshield.db"},
        },
        env_config,
    )

    pairs = merged.get("trading", {}).get("pairs", [])
    if not pairs:
        raise ConfigurationError("قائمة أزواج التداول فارغة في trading_pairs.yaml")

    risk = merged.get("risk", {})
    hybrid = merged.get("hybrid", {})
    execution = merged.get("execution", {})
    app = merged.get("app", {})
    database = merged.get("database", {})

    _settings = Settings(
        env=env_name,
        trading_pairs=list(pairs),
        risk_per_trade_pct=float(risk.get("risk_per_trade_pct", 1.0)),
        kill_switch_daily_pct=float(risk.get("kill_switch_daily_pct", -3.0)),
        gradual_growth_threshold_pct=float(risk.get("gradual_growth_threshold_pct", 20.0)),
        max_daily_trades=int(risk.get("max_daily_trades", 10)),
        loss_streak_limit=int(risk.get("loss_streak_limit", 3)),
        cooldown_hours=int(risk.get("cooldown_hours", 24)),
        loop_interval_seconds=int(app.get("loop_interval_seconds", 60)),
        log_level=str(app.get("log_level", "INFO")),
        db_path=str(os.getenv("DB_PATH") or database.get("path", "storage/db/goldenshield.db")),
        binance_api_key=os.getenv("BINANCE_API_KEY") or None,
        binance_api_secret=os.getenv("BINANCE_API_SECRET") or None,
        telegram_token=os.getenv("TELEGRAM_TOKEN") or None,
        telegram_chat_id=os.getenv("TELEGRAM_CHAT_ID") or None,
        telegram_bot_username=os.getenv("TELEGRAM_BOT_USERNAME") or None,
        telegram_backup_channel_id=os.getenv("TELEGRAM_BACKUP_CHANNEL_ID") or None,
        telegram_send_cycle_signals=os.getenv("TELEGRAM_SEND_CYCLE_SIGNALS", "true")
        .strip()
        .lower()
        in {"1", "true", "yes", "on"},
        # false = دخول تلقائي عند تأهل الإشارة (تجربة شهر)
        manual_entry_required=os.getenv("MANUAL_ENTRY_REQUIRED", "true")
        .strip()
        .lower()
        in {"1", "true", "yes", "on"},
        news_filter_enabled=bool(hybrid.get("news_filter_enabled", True)),
        news_blackout_minutes=int(hybrid.get("news_blackout_minutes", 5)),
        vix_threshold=float(hybrid.get("vix_threshold", 30.0)),
        bonds_yield_spike_pct=float(hybrid.get("bonds_yield_spike_pct", 3.0)),
        fear_greed_extreme_low=int(hybrid.get("fear_greed_extreme_low", 20)),
        fear_greed_extreme_high=int(hybrid.get("fear_greed_extreme_high", 80)),
        whale_wall_multiplier=float(hybrid.get("whale_wall_multiplier", 3.0)),
        institutional_min_levels=int(hybrid.get("institutional_min_levels", 2)),
        sentiment_anomaly_threshold=float(hybrid.get("sentiment_anomaly_threshold", 2.0)),
        execution_mode=str(
            os.getenv("EXECUTION_MODE") or execution.get("execution_mode", "paper")
        ).strip().lower(),
        paper_account_balance=float(execution.get("paper_account_balance", 10000.0)),
        default_sl_pct=float(execution.get("default_sl_pct", 0.03)),
        default_rr_ratio=float(execution.get("default_rr_ratio", 2.0)),
        dark_pool_max_chunk_usdt=float(execution.get("dark_pool_max_chunk_usdt", 500.0)),
        max_concurrent_positions=int(execution.get("max_concurrent_positions", 3)),
        partial_exit_pct=float(execution.get("partial_exit_pct", 0.5)),
        breakeven_enabled=bool(execution.get("breakeven_enabled", True)),
        correlation_groups=tuple(
            tuple(group) for group in execution.get("correlation_groups", [])
        ),
        min_account_balance=float(risk.get("min_account_balance", 100.0)),
        monte_carlo_simulations=int(risk.get("monte_carlo_simulations", 1000)),
        monte_carlo_min_win_rate=float(risk.get("monte_carlo_min_win_rate", 0.35)),
        mt5_enabled=os.getenv("MT5_ENABLED", "false").strip().lower()
        in {"1", "true", "yes", "on"},
        mt5_login=os.getenv("MT5_LOGIN") or None,
        mt5_password=os.getenv("MT5_PASSWORD") or None,
        mt5_server=os.getenv("MT5_SERVER") or None,
        mt5_broker=os.getenv("MT5_BROKER") or "XM",
        execution_backend=str(os.getenv("EXECUTION_BACKEND") or "binance").strip().lower(),
    )
    return _settings


def get_settings() -> Settings:
    if _settings is None:
        return load_settings()
    return _settings
