from __future__ import annotations

from dataclasses import dataclass

from config.settings import get_settings
from data.models.orderbook import OrderBook, OrderBookLevel
from data.orderbook_fetcher import OrderBookFetcher


@dataclass(frozen=True)
class WhaleZone:
    side: str
    price: float
    amount: float
    strength_ratio: float


@dataclass(frozen=True)
class WhaleTrackerResult:
    zones: tuple[WhaleZone, ...]
    has_whale_support: bool
    reason: str


def _average_amount(levels: tuple[OrderBookLevel, ...]) -> float:
    if not levels:
        return 0.0
    return sum(level.amount for level in levels) / len(levels)


def track_whales(symbol: str, *, orderbook: OrderBook | None = None) -> WhaleTrackerResult:
    settings = get_settings()
    book = orderbook or OrderBookFetcher().fetch(symbol, depth=20, use_cache=True)

    bid_avg = _average_amount(book.bids)
    ask_avg = _average_amount(book.asks)
    zones: list[WhaleZone] = []

    for level in book.bids:
        if bid_avg > 0 and level.amount >= bid_avg * settings.whale_wall_multiplier:
            zones.append(
                WhaleZone(
                    side="bid",
                    price=level.price,
                    amount=level.amount,
                    strength_ratio=level.amount / bid_avg,
                )
            )

    for level in book.asks:
        if ask_avg > 0 and level.amount >= ask_avg * settings.whale_wall_multiplier:
            zones.append(
                WhaleZone(
                    side="ask",
                    price=level.price,
                    amount=level.amount,
                    strength_ratio=level.amount / ask_avg,
                )
            )

    has_support = any(zone.side == "bid" for zone in zones)
    return WhaleTrackerResult(
        zones=tuple(zones),
        has_whale_support=has_support,
        reason=f"رصد {len(zones)} منطقة سيولة كبيرة",
    )
