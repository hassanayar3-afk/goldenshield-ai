from __future__ import annotations

from data.models.candle import Candle


def closes(candles: list[Candle]) -> list[float]:
    return [candle.close for candle in candles]


def sma(values: list[float], period: int) -> float | None:
    if len(values) < period or period < 1:
        return None
    window = values[-period:]
    return sum(window) / period


def rsi(values: list[float], period: int = 14) -> float | None:
    if len(values) < period + 1:
        return None

    gains = 0.0
    losses = 0.0
    for index in range(-period, 0):
        change = values[index] - values[index - 1]
        if change >= 0:
            gains += change
        else:
            losses -= change

    if losses == 0:
        return 100.0

    rs = gains / losses
    return 100 - (100 / (1 + rs))


def atr(candles: list[Candle], period: int = 14) -> float | None:
    if len(candles) < period + 1:
        return None

    true_ranges: list[float] = []
    for index in range(-period, 0):
        current = candles[index]
        previous = candles[index - 1]
        tr = max(
            current.high - current.low,
            abs(current.high - previous.close),
            abs(current.low - previous.close),
        )
        true_ranges.append(tr)

    return sum(true_ranges) / len(true_ranges)


def candle_body(candle: Candle) -> float:
    return abs(candle.close - candle.open)


def lower_wick(candle: Candle) -> float:
    return min(candle.open, candle.close) - candle.low


def upper_wick(candle: Candle) -> float:
    return candle.high - max(candle.open, candle.close)
