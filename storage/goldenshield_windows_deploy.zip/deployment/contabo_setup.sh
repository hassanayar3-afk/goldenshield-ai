#!/bin/bash
# إعداد Contabo VPS لـ GoldenShield AI
set -euo pipefail

echo "=== GoldenShield — Contabo Setup ==="
sudo apt-get update
sudo apt-get install -y docker.io docker-compose-plugin git curl

sudo systemctl enable docker
sudo systemctl start docker

sudo mkdir -p /opt/goldenshield
sudo chown "$USER":"$USER" /opt/goldenshield

echo "انسخ المشروع إلى /opt/goldenshield ثم:"
echo "  cp deployment/secrets.template /opt/goldenshield/.env"
echo "  docker compose up -d --build"
echo "  sudo cp deployment/systemd/goldenshield.service /etc/systemd/system/"
echo "  sudo systemctl enable goldenshield"
