#!/usr/bin/env python3
"""فحص صحة GoldenShield — خفيف ومستقل قدر الإمكان."""

from __future__ import annotations

import sys
from pathlib import Path
from urllib.request import urlopen

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE))


def main() -> int:
    try:
        from config.settings import load_settings

        settings = load_settings(reload=True)
    except Exception as exc:
        print("SETTINGS_FAIL", exc)
        return 1

    if not Path(settings.db_path).parent.exists():
        print("DB_DIR_MISSING")
        return 1

    try:
        with urlopen("https://api.binance.com/api/v3/ping", timeout=10) as resp:
            if getattr(resp, "status", 200) != 200:
                print("BINANCE_PING_FAIL")
                return 1
    except Exception as exc:
        print("BINANCE_PING_ERROR", exc)
        return 1

    print("OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
