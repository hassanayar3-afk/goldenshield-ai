from types import SimpleNamespace

from core.constants import SIGNAL_MIN_PERCENT, meets_signal_minimum
from operations.signal_filter import is_premium_trade_signal
from risk.risk_orchestrator import RiskApproval


def _result(**kwargs):
    return SimpleNamespace(**kwargs)


def test_premium_requires_buy_score_shadow_risk():
    result = _result(
        halted=False,
        signal="BUY SIGNAL",
        passed=True,
        score=8,
    )
    consensus = SimpleNamespace(approved=True)
    risk = RiskApproval(approved=True, reason="ok", amount=0.1, stop_loss=1.0, take_profit=2.0)
    assert is_premium_trade_signal(result, consensus=consensus, risk_approval=risk) is True


def test_wait_is_not_premium():
    result = _result(halted=False, signal="WAIT", passed=False, score=5)
    assert is_premium_trade_signal(result) is False


def test_buy_low_score_not_premium():
    result = _result(halted=False, signal="BUY SIGNAL", passed=False, score=6)
    assert is_premium_trade_signal(result) is False


def test_buy_score_eight_is_premium():
    result = _result(halted=False, signal="BUY SIGNAL", passed=True, score=8)
    consensus = SimpleNamespace(approved=True)
    risk = RiskApproval(approved=True, reason="ok", amount=0.1, stop_loss=1.0, take_profit=2.0)
    assert is_premium_trade_signal(result, consensus=consensus, risk_approval=risk) is True


def test_buy_score_seven_not_premium():
    result = _result(halted=False, signal="BUY SIGNAL", passed=True, score=7)
    assert is_premium_trade_signal(result) is False


def test_buy_without_risk_approval_not_premium():
    result = _result(halted=False, signal="BUY SIGNAL", passed=True, score=9)
    risk = RiskApproval(approved=False, reason="kill switch")
    assert is_premium_trade_signal(result, risk_approval=risk) is False
