from pathlib import Path

import pytest


@pytest.fixture
def project_root() -> Path:
    return Path(__file__).resolve().parent.parent


@pytest.fixture(autouse=True)
def reset_settings():
    """إعادة ضبط الإعدادات المخزّنة بين الاختبارات."""
    import config.settings as settings_module

    settings_module._settings = None
    yield
    settings_module._settings = None
