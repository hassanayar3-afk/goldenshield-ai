# GoldenShield AI — حالة الجلسة
> آخر تحديث: 2026-07-14

## الحالة
- المراحل 1–9 مكتملة + إصلاح فجوات التوقف
- **المرحلة 11:** Contabo 24/7 (paper)
- إصلاحات: دورة الاستيراد · healthcheck · استعادة المراكز · persist للمخاطر
- أرشيف النسخ: https://t.me/ilord16
- لا تشغّل البوت محلياً أثناء عمل السحابة

## Contabo
- IP: `169.58.8.253`
- المسار: `/opt/goldenshield`
- الحاوية: `goldenshield-bot`
- إعادة نشر: `DEPLOY_PASSWORD=... python scripts/deploy_to_contabo.py`

## Contabo
- IP: `169.58.8.253`
- المسار: `/opt/goldenshield`
- الحاوية: `goldenshield-bot` (Docker + systemd)
- إعادة نشر: `DEPLOY_PASSWORD=... python scripts/deploy_to_contabo.py`

## تشغيل محلي (اختياري)
```powershell
.\run.ps1
```

## MT5 / XM
- السيرفر محفوظ: `XMGlobal-MT5 10` | الحساب `345814054`
- الكود جاهز: `execution/mt5_bridge.py` — **غير مفعّل** على Contabo Linux
- للتفعيل الحقيقي: Windows VPS + دليل `docs/MT5_WINDOWS_SETUP.md`
- Contabo الحالي يبقى paper ولن يفتح صفقات XM

## العودة ليدوي لاحقاً
في `.env` على السيرفر: `MANUAL_ENTRY_REQUIRED=true` ثم إعادة تشغيل الحاوية
