# GoldenShield AI

نظام تداول آلي هجين — تحليل فني (SMC/FVG) + ذكاء سوقي (VIX، أخبار، مشاعر).

**وثائق التخطيط:** `GoldenShield_AI_Planning/` (خارج المستودع) — ابدأ من `phases/00_الفهرس_الهرمي.md`

---

## التشغيل السريع

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
$env:PYTHONIOENCODING = "utf-8"
python main.py
```

```powershell
pytest tests -v
```

---

## هيكل المشروع

```
GoldenShield_AI/
├── main.py                 # نقطة الدخول — حلقة async
├── requirements.txt
├── .env.example
├── pytest.ini
├── README.md
│
├── config/                 # المرحلة 1 — إعدادات YAML + .env
│   ├── settings.py
│   ├── trading_pairs.yaml
│   ├── risk_params.yaml
│   ├── hybrid_params.yaml
│   ├── economic_calendar.yaml
│   └── environments/       # dev | staging | production
│
├── data/                   # المرحلة 2 — جلب بيانات السوق (Binance/ccxt)
│   ├── exchange_client.py
│   ├── ohlcv_fetcher.py
│   ├── ticker_fetcher.py
│   ├── orderbook_fetcher.py
│   ├── volume_profile.py
│   ├── cache_manager.py
│   ├── connection_monitor.py
│   └── models/
│
├── core/                   # المراحل 3–4 — التحليل والذكاء الهجين
│   ├── analyzer.py
│   ├── hybrid_engine.py
│   ├── market_halt.py
│   ├── constants.py
│   ├── exceptions.py
│   ├── technical/          # SMC, FVG, Signal Scorer
│   ├── fundamental/        # أخبار اقتصادية
│   ├── sentiment/          # Fear & Greed، شذوذ
│   ├── macro/              # VIX، سندات
│   └── liquidity/          # حيتان، مناطق مؤسساتية
│
├── execution/              # المرحلة 5 — محرك التنفيذ
│   ├── trade_executor.py
│   ├── order_manager.py
│   ├── position_manager.py
│   ├── mutex_guard.py
│   ├── correlation_filter.py
│   ├── dark_pool_splitter.py
│   ├── breakeven_logic.py
│   ├── emergency_flat.py
│   ├── sl_tp_calculator.py
│   └── models/
├── risk/                   # المرحلة 6 — إدارة المخاطر
│   ├── risk_orchestrator.py
│   ├── lot_calculator.py
│   ├── kill_switch.py
│   ├── monte_carlo.py
│   └── ...
├── audit/                  # المرحلة 7 — تدقيق وShadow Execution
│   ├── audit_trail.py
│   ├── snapshot_recorder.py
│   ├── decision_logger.py
│   ├── shadow_executor.py
│   ├── consensus_gate.py
│   └── models/
├── operations/             # المرحلة 8 — Telegram والمراقبة ✅
│   ├── telegram_bot.py
│   ├── telegram_commands.py
│   ├── panic_button.py
│   ├── alert_dispatcher.py
│   ├── error_logger.py
│   ├── api_watchdog.py
│   ├── pre_flight_checklist.py
│   ├── daily_report.py
│   └── scheduler.py
├── database/               # المرحلة 9 — SQLite والنسخ الاحتياطي ✅
│   ├── connection.py
│   ├── backup_manager.py
│   ├── migrations/
│   └── repositories/
├── saas/                   # المرحلة 10 — منصة متعددة المستأجرين (قادم)
├── deployment/             # المرحلة 11 — Docker وCI/CD (قادم)
├── intelligence/           # المرحلة 12 — ML وRegime (قادم)
│
├── storage/                # ملفات تشغيل (ليست حزمة Python)
│   ├── db/                 # قواعد SQLite — لا تتداخل مع data/
│   └── logs/
│
└── tests/                  # اختبارات لكل طبقة
    ├── conftest.py
    ├── test_settings.py
    ├── core/
    └── data/
```

---

## حالة المراحل

| المرحلة | الوصف | الحالة |
|---------|-------|--------|
| 1 | الأساسيات والإعدادات | ✅ |
| 2 | طبقة البيانات | ✅ |
| 3 | التحليل الفني | ✅ |
| 4 | الذكاء الهجين | ✅ |
| 5 | محرك التنفيذ | ✅ |
| 6 | إدارة المخاطر | ✅ |
| 7 | التدقيق والظل | ✅ |
| 8 | التشغيل وTelegram | ✅ |
| 9 | قاعدة البيانات | ✅ |
| 11 | Docker والنشر (جزئي) | 🟡 جاهز محلياً |
| 10–12 | SaaS، ML | ⬜ |

---

## إعداد خارجي (خطوات يدوية قصيرة)

### 1) Binance Live
```powershell
# ضع المفاتيح في .env ثم:
.\.venv\Scripts\python.exe scripts\test_binance_connection.py
```

### 2) Google Drive
```powershell
pip install google-api-python-client google-auth google-auth-oauthlib
# ضع client_secret.json في storage/gdrive_client_secret.json
.\.venv\Scripts\python.exe scripts\setup_gdrive_oauth.py
# ضع GDRIVE_FOLDER_ID في .env
```

### 3) Docker (تشغيل 24/7)
```powershell
docker compose up -d --build
docker compose logs -f
```

### 4) تقويم اقتصادي بعيد
- انسخ `config/economic_calendar.remote.example.json` لسيرفرك
- فعّل `remote_feed_url` في `config/economic_calendar.yaml`

---

## ملاحظات معمارية

- **`data/`** = حزمة Python لجلب بيانات السوق — لا تُخزَّن فيها ملفات `.db`
- **`storage/db/`** = مسار قواعد البيانات (المرحلة 9) — يُضبط عبر `DB_PATH` أو YAML
- **التخطيط** في مجلد منفصل `GoldenShield_AI_Planning/` — افتح `GoldenShield_AI.code-workspace` لعرض الكود والتخطيط معاً
