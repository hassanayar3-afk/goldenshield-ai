@echo off
setlocal EnableExtensions
chcp 65001 >nul
title SAQR Engine v6.2.3 — صقر
cd /d "%~dp0"

echo.
echo  ╔══════════════════════════════════════════╗
echo  ║   SAQR v6.2.3 — Paper + Telegram Bridge   ║
echo  ╚══════════════════════════════════════════╝
echo.

if not exist ".env" (
  if exist "saqr.env" copy /Y saqr.env .env >nul
)
if not exist ".env" (
  if exist "env.template" copy /Y env.template .env >nul
  echo [OK] Created .env from env.template — add TELEGRAM_* keys.
)
if not exist ".env" (
  echo [ERROR] Missing .env in: %CD%
  pause
  exit /b 1
)

if exist "FIX_MY_ENV.bat" call FIX_MY_ENV.bat

if exist "bin\saqr.exe" (
  echo [RUN] Dashboard: http://127.0.0.1:8788
  echo       Paper 5000 USD ^| api.binance.com ^| Telegram bridge
  "bin\saqr.exe"
  goto :done
)

if exist "target\release\saqr.exe" (
  "target\release\saqr.exe"
  goto :done
)

set "PATH=%USERPROFILE%\.cargo\bin;%PATH%"
if exist "Cargo.toml" (
  cargo build --release
  if errorlevel 1 pause & exit /b 1
  "target\release\saqr.exe"
  goto :done
)

echo [ERROR] bin\saqr.exe not found.
pause
exit /b 1

:done
set "EC=%ERRORLEVEL%"
if not "%EC%"=="0" echo [EXIT] Code %EC%
pause
exit /b %EC%
