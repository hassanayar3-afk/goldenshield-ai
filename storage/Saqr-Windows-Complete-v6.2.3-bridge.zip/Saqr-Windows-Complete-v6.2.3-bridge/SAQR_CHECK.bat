@echo off
cd /d "%~dp0"
if exist "bin\saqr.exe" ("bin\saqr.exe" --check & pause) else (echo Missing bin\saqr.exe & pause)
