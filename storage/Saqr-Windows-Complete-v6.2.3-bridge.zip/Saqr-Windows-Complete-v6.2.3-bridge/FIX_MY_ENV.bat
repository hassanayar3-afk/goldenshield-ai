@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".env" if exist "env.template" copy /Y env.template .env
if not exist ".env" (
  echo Create .env first.
  pause
  exit /b 1
)
where python >nul 2>&1
if errorlevel 1 (
  echo Python 3 recommended for env sanitizer — skipping.
  exit /b 0
)
if exist "scripts\sanitize_saqr_env.py" (
  python scripts\sanitize_saqr_env.py .env
)
echo OK — .env ready.
exit /b 0
