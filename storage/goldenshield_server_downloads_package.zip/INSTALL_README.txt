GoldenShield clean server package

Target folder: C:\Users\Administrator\Downloads\GoldenShield
Demo mode: Binance Demo enabled
Launcher entrypoint: START_BOT.bat
Live signals window: BOT_WINDOW.bat
Pulse mode: 4 seconds
Telegram signals screen shows ready + WAIT entries
