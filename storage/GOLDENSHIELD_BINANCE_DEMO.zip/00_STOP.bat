@echo off
cd /d "%~dp0"
title Stop GoldenShield
echo Stopping GoldenShield bot...

REM No PowerShell - stop via Python helper if possible, else taskkill python running main
if exist "scripts\stop_bot_windows.py" (
  where python >nul 2>&1 && python scripts\stop_bot_windows.py && goto done
  where py >nul 2>&1 && py -3 scripts\stop_bot_windows.py && goto done
)

taskkill /F /IM python.exe /T >nul 2>&1
taskkill /F /IM pythonw.exe /T >nul 2>&1
taskkill /F /IM py.exe /T >nul 2>&1

:done
if not exist "storage\runtime" mkdir "storage\runtime" >nul 2>&1
echo stopped> "storage\runtime\user_stopped.flag"
echo Done. Binance Demo account stays on the exchange.
echo.
pause
