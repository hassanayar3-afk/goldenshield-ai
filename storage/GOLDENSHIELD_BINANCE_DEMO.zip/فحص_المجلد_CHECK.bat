@echo off
cd /d "%~dp0"
echo === GoldenShield folder check (Binance Demo) ===
echo Folder: %CD%
echo.
if not exist main.py (
  echo ERROR: main.py missing
  pause
  exit /b 1
)
if not exist .env (
  echo ERROR: .env missing
  pause
  exit /b 1
)
findstr /B /C:"EXECUTION_BACKEND=binance" .env >nul || echo WARN: EXECUTION_BACKEND should be binance
findstr /B /C:"BINANCE_DEMO_TRADING=true" .env >nul || echo WARN: BINANCE_DEMO_TRADING should be true
findstr /B /C:"MT5_ENABLED=true" .env >nul && echo WARN: MT5_ENABLED=true - should be false
echo.
where python >nul 2>&1 && python -c "import sys; print('python', sys.version)" 2>nul
where py >nul 2>&1 && py -3 -c "import sys; print('py -3', sys.version)" 2>nul
echo.
echo OK if main.py + .env + Python are shown.
pause
