@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title GoldenShield Binance Demo - KEEP OPEN

echo ============================================================
echo   GoldenShield AI - Binance Demo ONLY
echo   Folder: %CD%
echo ============================================================
echo.

if not exist "main.py" (
  echo [ERROR] main.py not found.
  echo Extract ZIP fully into one folder, then run START from that folder.
  echo Example: C:\GoldenShield_Binance\00_START.bat
  echo.
  echo Press any key to close...
  pause >nul
  exit /b 1
)

if not exist ".env" (
  echo [ERROR] .env missing. Extract the full package again.
  echo.
  echo Press any key to close...
  pause >nul
  exit /b 1
)

if not exist "storage\runtime" mkdir "storage\runtime" >nul 2>&1
if not exist "storage\logs" mkdir "storage\logs" >nul 2>&1
if exist "storage\runtime\user_stopped.flag" (
  echo [INFO] Removing user_stopped.flag
  del /f /q "storage\runtime\user_stopped.flag" >nul 2>&1
)

set "PYEXE="

for /f "delims=" %%i in ('where python 2^>nul') do (
  if not defined PYEXE (
    echo %%i | find /i "\WindowsApps\" >nul
    if errorlevel 1 (
      "%%i" -c "import sys" >nul 2>&1
      if not errorlevel 1 set "PYEXE=%%i"
    )
  )
)

if not defined PYEXE if exist "%LocalAppData%\Programs\Python\Python313\python.exe" set "PYEXE=%LocalAppData%\Programs\Python\Python313\python.exe"
if not defined PYEXE if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PYEXE=%LocalAppData%\Programs\Python\Python312\python.exe"
if not defined PYEXE if exist "C:\Users\Administrator\AppData\Local\Programs\Python\Python313\python.exe" set "PYEXE=C:\Users\Administrator\AppData\Local\Programs\Python\Python313\python.exe"
if not defined PYEXE if exist "C:\Python313\python.exe" set "PYEXE=C:\Python313\python.exe"
if not defined PYEXE if exist "C:\Python312\python.exe" set "PYEXE=C:\Python312\python.exe"

set "USE_PY_LAUNCHER=0"
if not defined PYEXE (
  where py >nul 2>&1
  if not errorlevel 1 (
    py -3 -c "import sys" >nul 2>&1
    if not errorlevel 1 (
      set "PYEXE=py"
      set "USE_PY_LAUNCHER=1"
    )
  )
)

if not defined PYEXE (
  echo [ERROR] Python not found.
  echo Install Python 3.12 or 3.13 from python.org
  echo Check: Add python.exe to PATH
  echo.
  echo Press any key to close...
  pause >nul
  exit /b 1
)

echo [OK] Python: !PYEXE!
if "!USE_PY_LAUNCHER!"=="1" (
  py -3 -c "import sys; print('[OK]', sys.version)"
) else (
  "!PYEXE!" -c "import sys; print('[OK]', sys.version)"
)
if errorlevel 1 (
  echo [ERROR] Python failed to run.
  echo.
  echo Press any key to close...
  pause >nul
  exit /b 1
)

echo.
echo [1/3] Installing requirements...
if "!USE_PY_LAUNCHER!"=="1" (
  py -3 -m pip install -r requirements.txt
) else (
  "!PYEXE!" -m pip install -r requirements.txt
)
if errorlevel 1 echo [WARN] pip issue - continuing

echo.
echo [2/3] Bootstrap storage...
if exist "scripts\bootstrap_storage.py" (
  if "!USE_PY_LAUNCHER!"=="1" (
    py -3 scripts\bootstrap_storage.py
  ) else (
    "!PYEXE!" scripts\bootstrap_storage.py
  )
)

echo.
echo [3/3] Starting bot...
echo ------------------------------------------------------------
echo   KEEP THIS WINDOW OPEN
echo   Telegram signals appear in about 1 minute
echo   To stop: run 00_STOP.bat or close this window
echo ------------------------------------------------------------
echo.

set "PYTHONPATH=%CD%"
set "PYTHONIOENCODING=utf-8"

:loop
echo [%DATE% %TIME%] starting main.py ...
if "!USE_PY_LAUNCHER!"=="1" (
  py -3 -u main.py
) else (
  "!PYEXE!" -u main.py
)
set "EC=!ERRORLEVEL!"
echo.
echo [%DATE% %TIME%] bot stopped - exit code !EC!
if exist "storage\runtime\user_stopped.flag" (
  echo Stopped by user. Will not auto-restart.
  echo.
  echo Press any key to close...
  pause >nul
  exit /b 0
)
echo Restarting in 8 seconds... Ctrl+C to cancel
timeout /t 8 /nobreak
goto loop
