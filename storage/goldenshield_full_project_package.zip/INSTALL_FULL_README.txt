GoldenShield full project package

1. Extract all files into C:\GoldenShield_Binance\
2. Install requirements with: pip install -r requirements.txt
3. Keep the included .env if you want the same current configuration.
4. Start with START_BOT.bat
5. Restart with REST_BOT.bat
6. Stop with STOP_BOT.bat
7. Watch live signals with BOT_WINDOW.bat
