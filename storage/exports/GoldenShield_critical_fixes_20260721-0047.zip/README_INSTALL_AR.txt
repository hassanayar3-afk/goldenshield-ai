# GoldenShield AI — حزمة الإصلاحات الحرجة + v1.1.2
البناء: 2026-07-18-halt-sl

## التثبيت
1) انسخ محتويات الأرشيف فوق مجلد GoldenShield_AI مع الحفاظ على المسارات.
2) أضف إلى .env:

REQUIRE_SL_ON_ALL_CHUNKS=true
CLOSE_NAKED_TICKETS=true
MANAGE_POSITIONS_DURING_HALT=true
PRE_EXECUTION_GATE_ENABLED=true
EMERGENCY_PROTOCOLS_ENABLED=true
EMERGENCY_ATR_SL_ENABLED=true
EMERGENCY_ATR_MULT=1.5
SL_RR_LOCK_ENABLED=true
SL_RR_LOCK_RATIO=3.0
VOLATILITY_GUARD_ENABLED=true
DEPLOY_HOST=
DEPLOY_USER=root
DEPLOY_PASSWORD=

3) أعد تشغيل البوت.
4) اختياري:
   .\.venv\Scripts\python.exe -m pytest tests\risk\test_critical_halt_and_sl.py tests\risk\test_v112_emergency_protocols.py -q

لا مكتبات جديدة. غيّر كلمة مرور Contabo القديمة إن لزم.
