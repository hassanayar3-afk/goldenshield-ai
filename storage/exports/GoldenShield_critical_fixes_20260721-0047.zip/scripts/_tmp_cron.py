"""إعداد cron لمراقب البنية — يعتمد على .env فقط."""

from __future__ import annotations

import sys
from pathlib import Path

import paramiko

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts._deploy_env import require_deploy_credentials  # noqa: E402


def main() -> int:
    host, user, password = require_deploy_credentials()
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        host,
        username=user,
        password=password,
        timeout=25,
        allow_agent=False,
        look_for_keys=False,
    )
    cmd = (
        "CRON_LINE='*/5 * * * * /opt/goldenshield/deployment/run_infrastructure_watchdog.sh'; "
        "( crontab -l 2>/dev/null | grep -v run_infrastructure_watchdog ; echo \"$CRON_LINE\" ) | crontab -; "
        "crontab -l"
    )
    _, stdout, _ = client.exec_command(cmd, timeout=30)
    print(stdout.read().decode())
    client.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
