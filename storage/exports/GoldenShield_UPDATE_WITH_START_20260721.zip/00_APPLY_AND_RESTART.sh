#!/bin/bash
# تطبيق حزمة الإصلاحات على Contabo ثم إعادة التشغيل
set -euo pipefail
APP_DIR=/opt/goldenshield
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
echo "=== Apply GoldenShield update from: $SCRIPT_DIR ==="
if [ ! -d "$APP_DIR" ]; then
  echo "ERROR: $APP_DIR not found"
  exit 1
fi
cd "$SCRIPT_DIR"
rsync -a --exclude '00_APPLY_AND_RESTART.sh' --exclude 'README_INSTALL_AR.txt' ./ "$APP_DIR"/
cd "$APP_DIR"
if [ -f .env ]; then
  grep -q 'REQUIRE_SL_ON_ALL_CHUNKS' .env || echo 'REQUIRE_SL_ON_ALL_CHUNKS=true' >> .env
  grep -q 'CLOSE_NAKED_TICKETS' .env || echo 'CLOSE_NAKED_TICKETS=true' >> .env
  grep -q 'MANAGE_POSITIONS_DURING_HALT' .env || echo 'MANAGE_POSITIONS_DURING_HALT=true' >> .env
  grep -q 'PRE_EXECUTION_GATE_ENABLED' .env || echo 'PRE_EXECUTION_GATE_ENABLED=true' >> .env
  grep -q 'EMERGENCY_PROTOCOLS_ENABLED' .env || echo 'EMERGENCY_PROTOCOLS_ENABLED=true' >> .env
fi
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --build
echo "=== DONE — check: docker logs -f goldenshield-bot ==="
