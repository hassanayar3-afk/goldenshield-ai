GoldenShield — حزمة تحديث مع ملفات START
========================================
البناء: 2026-07-18-halt-sl

محتويات مهمة:
- 00_START.bat / 00_STOP.bat / فحص_المجلد_CHECK.bat  (ويندوز MT5)
- 00_APPLY_AND_RESTART.sh  (سيرفر Contabo Linux)
- ملفات الإصلاحات الحرجة v1.1.2

======= Contabo (Linux) =======
1) ارفع الأرشيف إلى السيرفر
2) unzip -o GoldenShield_UPDATE_WITH_START_20260721.zip -d /tmp/gs_update
3) cd /tmp/gs_update
4) chmod +x 00_APPLY_AND_RESTART.sh
5) bash 00_APPLY_AND_RESTART.sh

======= Windows MT5 =======
1) Extract All إلى مجلد المشروع (أو C:\GoldenShield)
2) شغّل فحص_المجلد_CHECK.bat
3) شغّل 00_START.bat
