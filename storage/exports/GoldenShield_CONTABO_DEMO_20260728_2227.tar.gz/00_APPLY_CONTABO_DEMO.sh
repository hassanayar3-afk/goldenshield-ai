#!/bin/bash
# تثبيت/تحديث GoldenShield Demo على Contabo
set -euo pipefail
APP_DIR=/opt/goldenshield
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=== GoldenShield Contabo Demo Apply ==="
echo "Source: $SRC_DIR"
sudo mkdir -p "$APP_DIR" "$APP_DIR/storage/db/backups" "$APP_DIR/storage/logs"
sudo chown -R "$USER":"$USER" "$APP_DIR"

# نسخ الملفات (مع الإبقاء على .env الحالي إن وُجد)
rsync -a \
  --exclude '00_APPLY_CONTABO_DEMO.sh' \
  --exclude 'README_CONTABO_DEMO_AR.txt' \
  --exclude '.env' \
  "$SRC_DIR"/ "$APP_DIR"/

cd "$APP_DIR"

# إن لم يوجد .env: استخدم قالب الديمو
if [ ! -f .env ]; then
  if [ -f .env.demo ]; then
    cp .env.demo .env
    chmod 600 .env
    echo "تم إنشاء .env من .env.demo — راجع الأسرار إن لزم"
  else
    echo "ERROR: لا يوجد .env ولا .env.demo"
    exit 1
  fi
else
  # فرض إعدادات Demo على .env الموجود
  grep -q '^BINANCE_DEMO_TRADING=' .env && sed -i 's/^BINANCE_DEMO_TRADING=.*/BINANCE_DEMO_TRADING=true/' .env || echo 'BINANCE_DEMO_TRADING=true' >> .env
  grep -q '^EXECUTION_MODE=' .env && sed -i 's/^EXECUTION_MODE=.*/EXECUTION_MODE=paper/' .env || echo 'EXECUTION_MODE=paper' >> .env
  grep -q '^EXECUTION_BACKEND=' .env && sed -i 's/^EXECUTION_BACKEND=.*/EXECUTION_BACKEND=binance/' .env || echo 'EXECUTION_BACKEND=binance' >> .env
  grep -q '^MT5_ENABLED=' .env && sed -i 's/^MT5_ENABLED=.*/MT5_ENABLED=false/' .env || echo 'MT5_ENABLED=false' >> .env
  echo "تم تحديث أعلام Demo على .env الحالي"
fi

# Docker
if command -v docker >/dev/null 2>&1; then
  docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --build
  echo "=== DONE ==="
  docker compose ps
  echo "سجلات: docker compose logs -f"
else
  echo "Docker غير مثبت. شغّل: bash deployment/contabo_setup.sh"
  echo "أو: python3 -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt && python main.py"
fi
