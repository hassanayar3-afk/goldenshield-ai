GoldenShield AI — حزمة Contabo Demo
=====================================
البناء: 2026-07-29-v13-institutional
الوضع: Demo Trading فقط (ليس Live)

======= على سيرفر Contabo (Linux) =======
1) ارفع الملف إلى السيرفر (أو حمّله من تيليجرام إلى السيرفر)
2) mkdir -p /tmp/gs_demo && tar -xzf GoldenShield_CONTABO_DEMO_*.tar.gz -C /tmp/gs_demo
3) cd /tmp/gs_demo
4) chmod +x 00_APPLY_CONTABO_DEMO.sh
5) bash 00_APPLY_CONTABO_DEMO.sh

المسار النهائي: /opt/goldenshield

======= إعدادات Demo الإلزامية =======
BINANCE_DEMO_TRADING=true
EXECUTION_MODE=paper
EXECUTION_BACKEND=binance
MT5_ENABLED=false

ملف .env.demo قالب جاهز — انسخه إلى /opt/goldenshield/.env إن لم يكن موجوداً
ثم عدّل TELEGRAM_* و BINANCE_* إن احتجت.

======= ملاحظات =======
- لا تشغّل بوتين على نفس TELEGRAM_CHAT_ID معاً (محلي + سيرفر)
- Live الحقيقي يحتاج مفاتيح api.binance.com منفصلة لاحقاً
